/* Démarrage, navigation, barre de repos, installation et hors ligne. */
(function (root) {
  'use strict';
  const FM = root.FM, h = FM.h;
  const app = FM.app = { etat: null, invite: null, horsLigne: false };
  let routeCourante = '';

  app.sauver = () => FM.store.sauver(app.etat);

  app.rendre = function () {
    const [nom, ...reste] = location.hash.replace(/^#\//, '').split('/');
    const vue = Object.prototype.hasOwnProperty.call(FM.vues, nom) ? nom : 'accueil';
    const main = document.getElementById('vue');
    const meme = routeCourante === location.hash;
    const y = window.scrollY;
    if (vue !== 'profil') FM.oublierBrouillonProfil();
    main.replaceChildren(FM.vues[vue](app, reste.join('/')));
    routeCourante = location.hash;
    window.scrollTo(0, meme ? y : 0);
    const onglet = { exercice: 'exercices', detail: 'suivi', bilan: 'suivi', seance: 'accueil' }[vue] || vue;
    document.querySelectorAll('#menu a').forEach(a => {
      if (a.dataset.vue === onglet) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    if (vue !== 'seance') FM.ecran(false);
    app.rafraichirRepos();
  };

  app.aller = function (hash) { if (location.hash === hash) app.rendre(); else location.hash = hash; };

  app.demarrerSeance = function (jour) {
    if (!app.etat.active) { app.etat.active = FM.nouvelleSeance(app.etat, jour); app.sauver(); }
    app.aller('#/seance');
  };

  app.exporter = function () {
    app.etat.dernierExport = Date.now();
    app.sauver();
    FM.telecharger(`forge-muscu-${FM.cleJour(Date.now())}.json`, FM.store.exporter(app.etat));
    FM.toast('Sauvegarde téléchargée.');
  };

  app.installer = async function () {
    const i = app.invite;
    if (!i) return;
    app.invite = null;
    i.prompt();
    await i.userChoice;
    app.rendre();
  };

  /* La barre de repos reste affichée sur tous les écrans. */
  app.rafraichirRepos = function () {
    const barre = document.getElementById('repos');
    const r = app.etat && app.etat.repos;
    barre.hidden = !r;
    document.body.classList.toggle('avec-repos', !!r);
    if (!r) return;
    const s = (r.fin - Date.now()) / 1000;
    const fini = s <= 0;
    barre.classList.toggle('fini', fini);
    barre.querySelector('.temps').textContent = fini ? '+' + FM.mmss(-s) : FM.mmss(Math.ceil(s));
    barre.querySelector('.titre').textContent = fini ? 'Repos terminé' : 'Repos';
    barre.querySelector('.libelle').textContent = r.libelle;
    barre.querySelector('progress').value = fini ? 1 : 1 - s / r.total;
    barre.querySelector('[data-a=moins]').hidden = fini;
    barre.querySelector('[data-a=passer]').textContent = fini ? 'OK' : 'Passer';
    /* Après un rechargement, le navigateur exige un appui avant de rejouer un son. */
    barre.querySelector('[data-a=son]').hidden = fini || !app.etat.reglages.son || !['aucun', 'bloque'].includes(FM.timer.mode);
  };

  function demarrer() {
    app.etat = FM.store.charger();
    FM.store.avertir = FM.toast;
    FM.timer.init(app);
    const barre = document.getElementById('repos');
    const actions = { moins: () => FM.timer.ajuster(-15), plus: () => FM.timer.ajuster(15), passer: () => FM.timer.arreter(), son: () => { FM.timer.armer(); app.rafraichirRepos(); } };
    barre.querySelectorAll('[data-a]').forEach(b => b.addEventListener('click', actions[b.dataset.a]));
    window.addEventListener('hashchange', () => { document.querySelectorAll('dialog').forEach(d => d.remove()); app.rendre(); });
    /* Autre onglet ouvert : on recharge les données pour ne pas les écraser. */
    window.addEventListener('storage', ev => { if (ev.key === FM.store.CLE) { app.etat = FM.store.charger(); app.rendre(); } });
    window.addEventListener('beforeinstallprompt', ev => { ev.preventDefault(); app.invite = ev; if (location.hash === '#/profil') app.rendre(); });
    window.addEventListener('appinstalled', () => { app.invite = null; FM.toast('Application installée.'); });
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && app.etat.active && location.hash === '#/seance') FM.ecran(app.etat.reglages.ecranAllume);
    });
    app.rendre();
    app.sauver();
    if (FM.store.erreur) FM.modale('Attention', h('p', {}, FM.store.erreur));
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    horsLigne();
  }

  function horsLigne() {
    if (!('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
    const dejaControlee = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.register('sw.js').then(reg => {
      const proposer = () => {
        if (!reg.waiting || !navigator.serviceWorker.controller) return;
        const b = document.getElementById('maj');
        b.hidden = false;
        b.onclick = () => reg.waiting && reg.waiting.postMessage('activer');
      };
      proposer();
      reg.addEventListener('updatefound', () => { const w = reg.installing; if (w) w.addEventListener('statechange', proposer); });
    }).catch(() => {});
    navigator.serviceWorker.ready.then(() => { app.horsLigne = true; if (location.hash === '#/profil') app.rendre(); });
    let recharge = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => { if (dejaControlee && !recharge) { recharge = true; location.reload(); } });
  }

  demarrer();
})(window);
