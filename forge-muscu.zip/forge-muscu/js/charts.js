/* Graphiques SVG simples (une seule série par graphique). */
(function (root) {
  'use strict';
  const FM = root.FM || (root.FM = {});
  const NS = 'http://www.w3.org/2000/svg';
  const s = (tag, attrs, texte) => {
    const e = document.createElementNS(NS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    if (texte !== undefined) e.textContent = texte;
    return e;
  };
  const L = 340, H = 200, G = 44, D = 12, T = 14, B = 26;

  function echelle(min, max) {
    if (max === min) { max += 1; min = Math.max(0, min - 1); }
    const brut = (max - min) / 3, p = Math.pow(10, Math.floor(Math.log10(brut)));
    const pas = [1, 2, 2.5, 5, 10].map(m => m * p).find(v => v >= brut);
    const bas = Math.floor(min / pas) * pas, haut = Math.ceil(max / pas) * pas;
    const ticks = [];
    for (let v = bas; v <= haut + pas / 2; v += pas) ticks.push(Math.round(v * 100) / 100);
    return { bas, haut: ticks[ticks.length - 1], ticks };
  }

  function cadre(titre, ech) {
    const svg = s('svg', { viewBox: `0 0 ${L} ${H}`, role: 'img', 'aria-label': titre, class: 'graphe' });
    const y = v => T + (H - T - B) * (1 - (v - ech.bas) / (ech.haut - ech.bas));
    ech.ticks.forEach(v => {
      svg.append(s('line', { x1: G, x2: L - D, y1: y(v), y2: y(v), class: 'grille' }), s('text', { x: G - 6, y: y(v) + 4, 'text-anchor': 'end' }, FM.fmt(v)));
    });
    return { svg, y };
  }

  function boite(svg, info) {
    const d = document.createElement('figure');
    d.className = 'graphe-boite';
    const c = document.createElement('figcaption');
    c.textContent = info;
    c.setAttribute('aria-live', 'polite');
    d.append(svg, c);
    return { d, c };
  }

  /* points : [{etiquette, valeur}] */
  FM.courbe = function (points, unite, titre) {
    const vals = points.map(p => p.valeur);
    const ech = echelle(Math.min(...vals), Math.max(...vals));
    const { svg, y } = cadre(titre, ech);
    const n = points.length;
    const x = i => (n === 1 ? (G + L - D) / 2 : G + 8 + (L - D - G - 16) * i / (n - 1));
    if (n > 1) svg.append(s('polyline', { points: points.map((p, i) => `${x(i)},${y(p.valeur)}`).join(' '), class: 'trait' }));
    const dernier = points[n - 1];
    const { d, c } = boite(svg, `Dernier : ${FM.fmt(dernier.valeur)} ${unite} (${dernier.etiquette}). Touche un point pour le détail.`);
    points.forEach((p, i) => {
      svg.append(s('circle', { cx: x(i), cy: y(p.valeur), r: 4, class: 'point' }));
      const zone = s('circle', { cx: x(i), cy: y(p.valeur), r: 14, class: 'zone', tabindex: 0, 'aria-label': `${p.etiquette} : ${FM.fmt(p.valeur)} ${unite}` });
      const voir = () => { c.textContent = `${p.etiquette} : ${FM.fmt(p.valeur)} ${unite}`; };
      zone.addEventListener('click', voir); zone.addEventListener('focus', voir); zone.addEventListener('mouseenter', voir);
      svg.append(zone);
    });
    svg.append(s('text', { x: x(0), y: H - 8, 'text-anchor': n === 1 ? 'middle' : 'start' }, points[0].etiquette));
    if (n > 1) svg.append(s('text', { x: x(n - 1), y: H - 8, 'text-anchor': 'end' }, dernier.etiquette));
    return d;
  };

  FM.barres = function (points, unite, titre) {
    const ech = echelle(0, Math.max(1, ...points.map(p => p.valeur)));
    const { svg, y } = cadre(titre, ech);
    const w = (L - G - D) / points.length;
    const { d, c } = boite(svg, 'Semaines commençant le lundi. Touche une barre pour le détail.');
    points.forEach((p, i) => {
      const cx = G + w * i + w / 2;
      if (p.valeur > 0) svg.append(s('rect', { x: cx - w * 0.32, y: y(p.valeur), width: w * 0.64, height: y(0) - y(p.valeur), rx: 3, class: 'barre' }));
      const zone = s('rect', { x: G + w * i, y: T, width: w, height: H - T - B, class: 'zone', tabindex: 0, 'aria-label': `Semaine du ${p.etiquette} : ${FM.fmt(p.valeur)} ${unite}` });
      const voir = () => { c.textContent = `Semaine du ${p.etiquette} : ${FM.fmt(p.valeur)} ${unite}`; };
      zone.addEventListener('click', voir); zone.addEventListener('focus', voir); zone.addEventListener('mouseenter', voir);
      svg.append(zone);
      if (i % 2 === (points.length - 1) % 2) svg.append(s('text', { x: cx, y: H - 8, 'text-anchor': 'middle' }, p.etiquette));
    });
    return d;
  };

  /* Agrège des éléments sur les n dernières semaines. */
  FM.parSemaine = function (elements, date, valeur, n) {
    const debut = FM.lundi(Date.now());
    return Array.from({ length: n }, (_, k) => {
      const a = new Date(debut); a.setDate(a.getDate() - 7 * (n - 1 - k));
      const b = new Date(a); b.setDate(b.getDate() + 7);
      return { etiquette: `${a.getDate()}/${a.getMonth() + 1}`, valeur: elements.filter(e => date(e) >= a && date(e) < b).reduce((t, e) => t + valeur(e), 0) };
    });
  };
})(typeof window !== 'undefined' ? window : globalThis);
