/* Programme : consultation et modification. */
(function (root) {
  'use strict';
  const FM = root.FM, h = FM.h;
  let ouvert = null; // jour en cours de modification

  FM.regenerer = function (app) {
    app.etat.programme = FM.genererProgramme(app.etat.profil);
    ouvert = null;
    app.sauver();
    FM.toast('Nouveau programme généré.');
  };

  FM.vues.programme = function (app) {
    const e = app.etat, prog = e.programme, mat = e.profil.materiel;
    const maj = () => { app.sauver(); app.rendre(); };
    const noms = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
    const vue = h('div', {}, h('h1', {}, 'Programme'),
      h('p', { class: 'discret' }, `${e.profil.jours} séances full body par semaine (${e.profil.joursSemaine.slice().sort((a, b) => ((a + 6) % 7) - ((b + 6) % 7)).map(n => noms[n]).join(', ')}), séances de ${e.profil.duree} min.`));
    if (prog.manques.length) vue.append(h('p', { class: 'alerte' }, 'Avec ton matériel, ces mouvements sont absents ou très limités : ' + prog.manques.map(m => FM.NOMS_MOUVEMENTS[m]).join(', ') + '.'));
    const incompatibles = prog.jours.some(j => j.items.some(i => !FM.faisable(FM.EX[i.exId], mat)));
    if (incompatibles) vue.append(h('p', { class: 'alerte' }, 'Certains exercices demandent du matériel absent de ton profil. Remplace-les ou régénère le programme.'));

    prog.jours.forEach((jour, j) => {
      const edition = ouvert === jour.id;
      const carte = FM.carte(h('div', { class: 'entete' }, h('div', {}, h('h2', {}, jour.nom), h('p', { class: 'discret' }, `${jour.items.length} exercices · environ ${FM.duree(jour.items)} min`)),
        FM.btn(edition ? 'Terminé' : 'Modifier', () => { ouvert = edition ? null : jour.id; app.rendre(); }, edition ? 'primaire' : '', { 'aria-expanded': String(edition) })));
      if (!edition) carte.append(FM.apercu(jour));
      else {
        carte.append(FM.champ('Nom de la séance', h('input', { type: 'text', maxlength: 60, value: jour.nom, onchange: ev => { jour.nom = ev.target.value.trim() || jour.nom; maj(); } })));
        jour.items.forEach((it, i) => {
          const ex = FM.EX[it.exId];
          const champs = {};
          /* La cohérence min ≤ max est appliquée une fois la saisie terminée. */
          const accorder = cle => {
            if (it.max < it.min) {
              const autre = cle === 'max' ? 'min' : 'max';
              it[autre] = it[cle]; champs[autre].definir(it[autre]); app.sauver();
            }
          };
          const reg = (label, cle, pas, min, max) => (champs[cle] = FM.stepper({ label, valeur: it[cle], pas, min, max,
            onchange: v => { it[cle] = Math.round(v); app.sauver(); },
            onfin: cle === 'min' || cle === 'max' ? () => accorder(cle) : null }));
          const deplacer = d => { const [x] = jour.items.splice(i, 1); jour.items.splice(i + d, 0, x); maj(); };
          carte.append(h('div', { class: 'bloc' }, h('h3', {}, ex.nom),
            h('div', { class: 'grille2' }, reg('Séries', 'series', 1, 1, 12), reg('Repos (s)', 'repos', 15, 0, 600),
              reg(ex.mode === 'temps' ? 'Secondes min' : 'Répétitions min', 'min', ex.mode === 'temps' ? 5 : 1, 1, 600),
              reg(ex.mode === 'temps' ? 'Secondes max' : 'Répétitions max', 'max', ex.mode === 'temps' ? 5 : 1, 1, 600)),
            h('div', { class: 'rangee' },
              FM.btn('↑ Monter', () => deplacer(-1), '', { disabled: i === 0 }),
              FM.btn('↓ Descendre', () => deplacer(1), '', { disabled: i === jour.items.length - 1 }),
              FM.btn('Remplacer', () => FM.choisirExercice('Remplacer ' + ex.nom, FM.alternatives(ex.id, mat), id => { jour.items[i] = FM.item(id, e.profil); maj(); })),
              FM.btn('Retirer', () => FM.confirmer('Retirer l’exercice ?', ex.nom, 'Retirer', () => { jour.items.splice(i, 1); maj(); }, true), 'danger'))));
        });
        carte.append(FM.btn('+ Ajouter un exercice', () => FM.choisirExercice('Ajouter un exercice', FM.EXERCICES.filter(x => FM.faisable(x, mat) && !jour.items.some(i => i.exId === x.id)).map(x => x.id),
          id => { jour.items.push(FM.item(id, e.profil)); maj(); }), 'primaire geant'));
        if (!jour.items.some(i => FM.EX[i.exId].muscles.includes('abdos'))) carte.append(h('p', { class: 'alerte' }, 'Cette séance n’a plus d’exercice abdominal.'));
        carte.append(h('div', { class: 'rangee' },
          FM.btn('Placer avant', () => { const [x] = prog.jours.splice(j, 1); prog.jours.splice(j - 1, 0, x); maj(); }, '', { disabled: j === 0 }),
          FM.btn('Supprimer la séance', () => FM.confirmer('Supprimer la séance ?', jour.nom + ' sera retirée du programme. L’historique reste.', 'Supprimer', () => { prog.jours.splice(j, 1); ouvert = null; maj(); }, true), 'danger', { disabled: prog.jours.length === 1 })));
      }
      vue.append(carte);
    });

    vue.append(h('div', { class: 'rangee' },
      FM.btn('+ Nouvelle séance', () => { const s = { id: FM.uid(), nom: 'Séance ' + (prog.jours.length + 1), items: [] }; prog.jours.push(s); ouvert = s.id; maj(); }, '', { disabled: prog.jours.length >= 7 }),
      FM.btn('Régénérer le programme', () => FM.confirmer('Régénérer ?', 'Le programme actuel et tes modifications seront remplacés. L’historique reste.', 'Régénérer', () => { FM.regenerer(app); app.rendre(); }, true))));

    const vol = FM.volumeHebdo(prog, e.profil.jours);
    const max = Math.max(1, ...Object.values(vol));
    vue.append(FM.carte(h('h2', {}, 'Séries par muscle et par semaine'), h('p', { class: 'discret' }, 'Muscle principal : 1 série. Muscle secondaire : 0,5.'),
      Object.entries(vol).map(([m, v]) => h('div', { class: 'jauge' }, h('span', {}, FM.MUSCLES[m] + (e.profil.priorites.includes(m) ? ' ★' : '')),
        h('div', { class: 'piste' }, h('div', { style: `width:${v / max * 100}%` })), h('strong', {}, FM.fmt(v))))));
    return vue;
  };
})(typeof window !== 'undefined' ? window : globalThis);
