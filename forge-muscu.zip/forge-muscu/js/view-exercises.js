/* Bibliothèque d'exercices et fiche détaillée. */
(function (root) {
  'use strict';
  const FM = root.FM, h = FM.h;
  const filtre = { q: '', muscle: '', materiel: false };
  const sans = s => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

  FM.materielRequis = ex => (ex.equip[0].length ? ex.equip.map(g => g.map(m => FM.MATERIEL[m]).join(' + ')).join(' ou ') : 'Poids du corps');

  FM.vues.exercices = function (app) {
    const liste = h('div', { class: 'liste' }), compte = h('p', { class: 'discret', 'aria-live': 'polite' });
    const remplir = () => {
      const r = FM.EXERCICES.filter(e => sans(e.nom).includes(sans(filtre.q)) && (!filtre.muscle || e.muscles.includes(filtre.muscle)) && (!filtre.materiel || FM.faisable(e, app.etat.profil.materiel)));
      compte.textContent = `${r.length} exercice(s)`;
      liste.replaceChildren(...r.map(e => h('a', { class: 'ligne', href: '#/exercice/' + e.id }, h('strong', {}, e.nom), h('small', {}, e.muscles.map(m => FM.MUSCLES[m]).join(', ') + ' · ' + FM.materielRequis(e)))));
    };
    remplir();
    return h('div', {}, h('h1', {}, 'Exercices'),
      h('input', { type: 'search', placeholder: 'Rechercher un exercice', 'aria-label': 'Rechercher un exercice', value: filtre.q, oninput: e => { filtre.q = e.target.value; remplir(); } }),
      FM.choix([['', 'Tous'], ...Object.entries(FM.MUSCLES)], filtre.muscle, v => { filtre.muscle = v; remplir(); }, 'Filtrer par muscle'),
      h('label', { class: 'case' }, h('input', { type: 'checkbox', checked: filtre.materiel, onchange: e => { filtre.materiel = e.target.checked; remplir(); } }), 'Seulement avec mon matériel'),
      compte, liste);
  };

  /* Contenu d'une fiche, réutilisé pendant la séance. */
  FM.fiche = ex => [
    h('h3', {}, 'Consignes'), h('ol', {}, ex.consignes.map(c => h('li', {}, c))),
    h('h3', {}, 'Erreurs à éviter'), h('ul', { class: 'erreurs' }, ex.erreurs.map(c => h('li', {}, c)))];

  FM.vues.exercice = function (app, id) {
    const ex = FM.EX[id];
    if (!ex) return h('div', {}, h('h1', {}, 'Exercice introuvable'), FM.lien('#/exercices', 'Retour à la liste', 'btn'));
    const e = app.etat, records = FM.records(e.seances, id), hist = FM.historiqueExercice(e.seances, id).reverse();
    return h('div', {}, FM.btn('← Retour', () => history.back(), 'petit'), h('h1', {}, ex.nom),
      h('p', { class: 'discret' }, ex.muscles.map(m => FM.MUSCLES[m]).join(', ') + (ex.secondaires.length ? ' · secondaires : ' + ex.secondaires.map(m => FM.MUSCLES[m]).join(', ') : '')),
      h('p', {}, 'Matériel : ' + FM.materielRequis(ex) + (ex.niveau === 2 ? ' · niveau intermédiaire' : ' · accessible aux débutants')),
      FM.carte(FM.fiche(ex), h('p', { class: 'alerte' }, 'Arrête en cas de douleur vive ou inhabituelle.')),
      FM.carte(h('h2', {}, 'Alternatives'), h('div', { class: 'liste' }, FM.alternatives(id).map(a => h('a', { class: 'ligne', href: '#/exercice/' + a }, h('strong', {}, FM.EX[a].nom),
        h('small', {}, FM.materielRequis(FM.EX[a]) + (FM.faisable(FM.EX[a], e.profil.materiel) ? '' : ' · matériel manquant')))))),
      records.length ? FM.carte(h('h2', {}, 'Tes records'), FM.tableRecords(records)) : null,
      hist.length ? FM.carte(h('h2', {}, 'Dernières fois'), h('ul', {}, hist.slice(0, 5).map(x => h('li', {}, FM.dateCourte(x.date) + ' : ' + x.series.map(s => FM.resumeSerie(ex, s)).join(' · ')))),
        FM.btn('Voir la progression', () => { FM.choixGraphe = id; app.aller('#/suivi/progres'); })) : null);
  };

  FM.tableRecords = records => h('dl', { class: 'records' }, records.map(r => [h('dt', {}, r.nom), h('dd', {}, `${FM.fmt(r.valeur)} ${r.unite}`, h('small', {}, FM.dateCourte(r.date)))]));
})(typeof window !== 'undefined' ? window : globalThis);
