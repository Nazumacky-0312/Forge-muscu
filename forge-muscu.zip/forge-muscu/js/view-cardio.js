/* Cardio et autres sports. */
(function (root) {
  'use strict';
  const FM = root.FM, h = FM.h;
  const niveau = n => (n <= 3 ? 'légère' : n <= 6 ? 'modérée' : n <= 8 ? 'soutenue' : 'maximale');
  let brouillon = null, limite = 20;

  const neuf = () => ({ id: null, date: FM.cleJour(Date.now()), sport: FM.SPORTS[0], duree: 30, intensite: 5, distance: 0, note: '' });

  function formulaire(b, valider, texte) {
    const sortie = h('output', {}, `${b.intensite} / 10 · ${niveau(b.intensite)}`);
    return h('div', {},
      FM.champ('Activité', h('select', { value: b.sport, onchange: e => { b.sport = e.target.value; } }, [...new Set([...FM.SPORTS, b.sport])].map(s => h('option', { value: s }, s)))),
      FM.champ('Date', h('input', { type: 'date', value: b.date, max: FM.cleJour(Date.now()), onchange: e => { b.date = e.target.value; } })),
      FM.stepper({ label: 'Durée (minutes)', valeur: b.duree, pas: 5, min: 1, max: 1440, onchange: v => { b.duree = Math.round(v); } }),
      FM.champ('Intensité ressentie', h('input', { type: 'range', min: 1, max: 10, step: 1, value: b.intensite, oninput: e => { b.intensite = Number(e.target.value); sortie.textContent = `${b.intensite} / 10 · ${niveau(b.intensite)}`; } })), sortie,
      FM.stepper({ label: 'Distance en km (facultatif)', valeur: b.distance, pas: 0.5, min: 0, max: 2000, onchange: v => { b.distance = v; } }),
      FM.champ('Note (facultatif)', h('input', { type: 'text', maxlength: 500, value: b.note, oninput: e => { b.note = e.target.value; } })),
      FM.btn(texte, valider, 'primaire geant'));
  }

  function versEntree(b) {
    const [a, m, j] = String(b.date).split('-').map(Number);
    const date = new Date(a, m - 1, j, 12).getTime();
    if (!Number.isFinite(date)) { FM.toast('Choisis une date.'); return null; }
    if (FM.cleJour(date) > FM.cleJour(Date.now())) { FM.toast('La date est dans le futur.'); return null; }
    if (!(b.duree >= 1)) { FM.toast('Indique une durée.'); return null; }
    return { id: b.id || FM.uid(), date, sport: b.sport, duree: b.duree, intensite: b.intensite, distance: b.distance, note: b.note.trim() };
  }

  FM.vues.cardio = function (app) {
    const e = app.etat;
    if (!brouillon) brouillon = neuf();
    const vue = h('div', {}, h('h1', {}, 'Cardio et sports'),
      FM.carte(h('h2', {}, 'Nouvelle activité'), formulaire(brouillon, () => {
        const x = versEntree(brouillon);
        if (!x) return;
        e.cardio.push(x); brouillon = null; app.sauver(); app.rendre(); FM.toast('Activité enregistrée.');
      }, 'Enregistrer l’activité')),
      h('p', { class: 'alerte' }, 'Échauffe-toi progressivement, hydrate-toi et arrête en cas de douleur ou de malaise.'));
    if (!e.cardio.length) return vue;
    vue.append(FM.carte(h('h2', {}, 'Minutes par semaine'), FM.barres(FM.parSemaine(e.cardio, c => c.date, c => c.duree, 8), 'min', 'Minutes de cardio par semaine')),
      FM.carte(h('h2', {}, 'Charge d’entraînement'), h('p', { class: 'discret' }, 'Durée × intensité, additionnée par semaine. Évite les hausses brutales.'),
        FM.barres(FM.parSemaine(e.cardio, c => c.date, c => c.duree * c.intensite, 8), 'points', 'Charge cardio par semaine')));
    const tri = [...e.cardio].sort((a, b) => b.date - a.date);
    vue.append(h('h2', {}, 'Historique'), h('div', { class: 'liste' }, tri.slice(0, limite).map(c => h('div', { class: 'ligne' }, h('strong', {}, `${c.sport} · ${c.duree} min`),
      h('small', {}, `${FM.dateCourte(c.date)} · intensité ${c.intensite}/10${c.distance ? ` · ${FM.fmt(c.distance)} km` : ''}${c.note ? ' · ' + c.note : ''}`),
      h('div', { class: 'rangee' }, FM.btn('Modifier', () => {
        const b = Object.assign({}, c, { date: FM.cleJour(c.date) });
        FM.modale('Modifier l’activité', formulaire(b, () => {
          const x = versEntree(b);
          if (!x) return;
          Object.assign(c, x); app.sauver(); document.querySelector('dialog.modale').remove(); app.rendre();
        }, 'Enregistrer'), [{ texte: 'Annuler' }]);
      }, 'petit'), FM.btn('Supprimer', () => FM.confirmer('Supprimer l’activité ?', `${c.sport} du ${FM.dateCourte(c.date)}`, 'Supprimer', () => { e.cardio = e.cardio.filter(x => x !== c); app.sauver(); app.rendre(); }, true), 'petit danger'))))));
    if (tri.length > limite) vue.append(FM.btn('Voir plus', () => { limite += 20; app.rendre(); }, 'geant'));
    return vue;
  };
})(typeof window !== 'undefined' ? window : globalThis);
