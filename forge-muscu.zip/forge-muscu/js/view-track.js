/* Suivi : historique, records, graphiques. */
(function (root) {
  'use strict';
  const FM = root.FM, h = FM.h;
  let mesure = null;

  const faits = e => [...new Set(e.seances.flatMap(s => s.exercices.filter(x => x.series.length).map(x => x.exId)))]
    .sort((a, b) => FM.EX[a].nom.localeCompare(FM.EX[b].nom, 'fr'));
  const onglets = actif => h('nav', { class: 'onglets' }, [['historique', 'Historique'], ['records', 'Records'], ['progres', 'Graphiques']]
    .map(([k, t]) => h('a', { href: '#/suivi/' + k, class: 'btn puce', 'aria-current': k === actif ? 'page' : null }, t)));

  FM.vues.suivi = function (app, onglet) {
    const e = app.etat;
    const o = ['records', 'progres'].includes(onglet) ? onglet : 'historique';
    const vue = h('div', {}, h('h1', {}, 'Suivi'), onglets(o));
    if (!e.seances.length) {
      vue.append(FM.carte(h('p', {}, 'Rien à afficher pour l’instant. Termine ta première séance de musculation.'), FM.lien('#/accueil', 'Voir la séance du jour', 'btn primaire geant')));
      return vue;
    }
    if (o === 'historique') {
      vue.append(h('div', { class: 'liste' }, [...e.seances].sort((a, b) => b.debut - a.debut).map(s => h('a', { class: 'ligne', href: '#/detail/' + s.id }, h('strong', {}, s.nom + (s.exercices.some(x => x.douleur) ? ' ⚠' : '')),
        h('small', {}, `${FM.dateCourte(s.debut)} · ${Math.max(1, Math.round((s.fin - s.debut) / 60000))} min · ${s.exercices.reduce((t, x) => t + x.series.length, 0)} séries`)))));
    } else if (o === 'records') {
      for (const id of faits(e)) {
        const r = FM.records(e.seances, id);
        if (r.length) vue.append(FM.carte(h('h2', {}, FM.lien('#/exercice/' + id, FM.EX[id].nom)), FM.tableRecords(r)));
      }
      vue.append(h('p', { class: 'discret' }, '1RM estimé : formule d’Epley, séries de 12 répétitions au plus. C’est une estimation, pas un test.'));
    } else {
      vue.append(FM.carte(h('h2', {}, 'Séances par semaine'), FM.barres(FM.parSemaine(e.seances, s => s.debut, () => 1, 8), 'séance(s)', 'Séances par semaine')));
      const ids = faits(e);
      if (!ids.length) return vue;
      if (!ids.includes(FM.choixGraphe)) FM.choixGraphe = ids[0];
      const zone = h('div');
      const dessiner = () => {
        const ex = FM.EX[FM.choixGraphe], hist = FM.historiqueExercice(e.seances, ex.id), ind = FM.indicateurs(ex, hist);
        if (!ind.some(i => i[0] === mesure)) mesure = ind[0][0];
        const [, nom, unite] = ind.find(i => i[0] === mesure);
        const pts = hist.map(x => ({ etiquette: new Date(x.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }), valeur: FM.stats(x.series)[mesure] })).filter(x => x.valeur > 0).slice(-30);
        zone.replaceChildren(FM.choix(ind.map(i => [i[0], i[1]]), mesure, v => { mesure = v; dessiner(); }, 'Mesure'), h('h3', {}, `${nom} (${unite})`),
          pts.length ? FM.courbe(pts, unite, `${nom} : ${ex.nom}`) : h('p', {}, 'Pas encore de valeur pour cette mesure.'),
          pts.length === 1 ? h('p', { class: 'discret' }, 'La courbe apparaîtra dès la deuxième séance.') : h('span'));
      };
      vue.append(FM.carte(h('h2', {}, 'Progression par exercice'), FM.champ('Exercice', h('select', { value: FM.choixGraphe, onchange: ev => { FM.choixGraphe = ev.target.value; dessiner(); } }, ids.map(i => h('option', { value: i }, FM.EX[i].nom)))), zone));
      dessiner();
    }
    return vue;
  };

  FM.vues.detail = function (app, id) {
    const e = app.etat, s = e.seances.find(x => x.id === id);
    if (!s) return h('div', {}, h('h1', {}, 'Séance introuvable'), FM.lien('#/suivi', 'Retour', 'btn'));
    const noms = { facile: 'facile', correct: 'correct', difficile: 'difficile', echec: 'à l’échec' };
    return h('div', {}, FM.lien('#/suivi', '← Historique', 'btn petit'), h('h1', {}, s.nom),
      h('p', { class: 'discret' }, `${FM.dateLongue(s.debut)} · ${Math.max(1, Math.round((s.fin - s.debut) / 60000))} min`),
      s.note ? h('p', { class: 'info' }, s.note) : null,
      s.exercices.map(x => {
        const ex = FM.EX[x.exId];
        return FM.carte(h('h3', {}, FM.lien('#/exercice/' + ex.id, ex.nom)),
          x.series.length ? h('ol', {}, x.series.map(y => h('li', {}, FM.resumeSerie(ex, y)))) : h('p', {}, 'Aucune série validée.'),
          x.ressenti ? h('p', { class: 'discret' }, 'Ressenti : ' + noms[x.ressenti]) : null, x.douleur ? h('p', { class: 'alerte' }, 'Douleur signalée.') : null);
      }),
      FM.btn('Voir le bilan', () => app.aller('#/bilan/' + s.id), 'geant'),
      FM.btn('Supprimer cette séance', () => FM.confirmer('Supprimer la séance ?', 'Cette action est définitive. Les records seront recalculés.', 'Supprimer', () => {
        e.seances = e.seances.filter(x => x !== s); app.sauver(); app.aller('#/suivi');
      }, true), 'danger geant'));
  };
})(typeof window !== 'undefined' ? window : globalThis);
