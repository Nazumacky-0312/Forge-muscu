/* Séance guidée et bilan. */
(function (root) {
  'use strict';
  const FM = root.FM, h = FM.h;
  let chrono = null; // { debut, exId } pour les exercices au temps

  /* Prépare les séries d'un exercice à partir de la cible acceptée ou de la dernière fois. */
  FM.preparerEntree = function (etat, it) {
    const ex = FM.EX[it.exId];
    const hist = FM.historiqueExercice(etat.seances, it.exId);
    const dernier = hist[hist.length - 1];
    const cible = etat.cibles[it.exId];
    const series = Array.from({ length: it.series }, (_, i) => {
      if (cible) return { kg: cible.kg, reps: cible.reps, fait: false };
      const s = dernier && (dernier.series[i] || dernier.series[dernier.series.length - 1]);
      return { kg: s ? s.kg : 0, reps: s ? s.reps : it.min, fait: false };
    });
    return { exId: it.exId, prevu: Object.assign({}, it), ressenti: null, douleur: false, series };
  };

  FM.nouvelleSeance = (etat, jour) => ({
    id: FM.uid(), jourId: jour.id, nom: jour.nom, debut: Date.now(), fin: 0, note: '', echauffement: false, index: 0,
    exercices: jour.items.map(it => FM.preparerEntree(etat, it))
  });

  function echauffement(app, a) {
    const premier = a.exercices.map(x => ({ x, ex: FM.EX[x.exId] })).find(o => o.ex.mode === 'charge' && o.ex.poly);
    let montee = null;
    if (premier) {
      const kg = premier.x.series[0].kg;
      montee = h('li', {}, kg > 0
        ? `Montée en charge sur « ${premier.ex.nom} » : ${[[0.5, 8], [0.7, 5], [0.85, 2]].map(([p, r]) => `${FM.fmt(FM.arrondir(kg * p, premier.ex.inc))} kg × ${r}`).join(', puis ')}.`
        : `Sur « ${premier.ex.nom} » : 2 à 3 séries légères en montant progressivement.`);
    }
    const fini = () => { a.echauffement = true; FM.timer.arreter(); app.rendre(); window.scrollTo(0, 0); };
    return h('div', {}, h('p', { class: 'surtitre' }, a.nom), h('h1', {}, 'Échauffement'),
      FM.carte(h('ul', { class: 'cocher' }, ['5 min de cardio léger (vélo, rameur, marche rapide, corde).', '10 cercles de bras dans chaque sens et 10 rotations de hanches.', '10 squats sans charge et 10 fentes.', '10 pompes mains surélevées et 10 rétractions d’omoplates.', '30 secondes de rotations des poignets.'].map(t => h('li', {}, h('label', { class: 'case' }, h('input', { type: 'checkbox' }), t))), montee),
        FM.btn('Lancer 5 minutes', () => FM.timer.demarrer(300, 'Échauffement'), 'geant')),
      h('p', { class: 'alerte' }, 'Arrête en cas de douleur. Douleur dans la poitrine, vertige ou malaise : stop et appelle le 15 ou le 112.'),
      FM.btn('Échauffement fait, on y va', fini, 'primaire geant'),
      h('div', { class: 'rangee' }, FM.btn('Passer l’échauffement', fini), FM.btn('Annuler la séance', () => annuler(app), 'danger')));
  }

  function annuler(app) {
    const n = app.etat.active.exercices.reduce((t, x) => t + x.series.filter(s => s.fait).length, 0);
    FM.confirmer('Abandonner la séance ?', n ? `Les ${n} série(s) validée(s) ne seront pas enregistrées.` : 'Rien ne sera enregistré.', 'Abandonner', () => {
      app.etat.active = null; chrono = null; FM.timer.arreter(); FM.ecran(false); app.aller('#/accueil');
    }, true);
  }

  FM.terminerSeance = function (app) {
    const e = app.etat, a = e.active;
    const utiles = a.exercices.filter(x => x.douleur || x.series.some(s => s.fait && s.reps > 0));
    if (!utiles.some(x => x.series.some(s => s.fait))) return annuler(app);
    const restantes = a.exercices.reduce((t, x) => t + x.series.filter(s => !s.fait).length, 0);
    const valider = () => {
      const s = Object.assign({}, a, { fin: Date.now(), exercices: utiles.map(x => Object.assign({}, x, { series: x.series.filter(y => y.fait) })) });
      e.seances.push(s);
      s.exercices.forEach(x => { if (x.series.length) delete e.cibles[x.exId]; });
      e.active = null; chrono = null;
      FM.timer.arreter(); FM.ecran(false); app.sauver(); app.aller('#/bilan/' + s.id);
    };
    FM.confirmer('Terminer la séance ?', restantes ? `Il reste ${restantes} série(s) non validée(s). Elles ne seront pas comptées.` : 'Toutes les séries sont faites.', 'Enregistrer', valider);
  };

  function signalerDouleur(app, a, entree) {
    const ex = FM.EX[entree.exId];
    const noter = () => { entree.douleur = true; FM.timer.arreter(); chrono = null; app.sauver(); };
    FM.modale('Arrête cet exercice', [h('p', {}, 'Ne force jamais sur une douleur vive, articulaire ou inhabituelle. Si elle persiste, consulte un médecin ou un kinésithérapeute.'),
      h('p', { class: 'alerte' }, 'Douleur dans la poitrine, difficulté à respirer, malaise : appelle le 15 ou le 112.')], [
      { texte: 'Choisir une alternative', classe: 'primaire', action: () => { noter(); app.rendre(); remplacer(app, a, entree); } },
      { texte: 'Passer cet exercice', action: () => { noter(); a.index = Math.min(a.exercices.length - 1, a.index + 1); app.rendre(); } },
      { texte: 'Terminer la séance', classe: 'danger', action: () => { noter(); app.rendre(); FM.terminerSeance(app); } },
      { texte: 'Fausse alerte' }]);
  }

  function remplacer(app, a, entree) {
    FM.choisirExercice('Remplacer par', FM.alternatives(entree.exId, app.etat.profil.materiel), id => {
      const base = FM.item(id, app.etat.profil);
      const faites = entree.series.filter(s => s.fait).length;
      base.series = Math.max(1, entree.prevu.series - faites);
      const neuve = FM.preparerEntree(app.etat, base);
      const i = a.exercices.indexOf(entree);
      if (faites || entree.douleur) {
        entree.series = entree.series.filter(s => s.fait);
        a.exercices.splice(i + 1, 0, neuve); a.index = i + 1;
      } else a.exercices[i] = neuve;
      chrono = null; app.sauver(); app.rendre();
    });
  }

  FM.vues.seance = function (app) {
    const e = app.etat, a = e.active;
    if (!a) return h('div', {}, h('h1', {}, 'Aucune séance en cours'), FM.lien('#/accueil', 'Retour à l’accueil', 'btn primaire geant'));
    FM.ecran(e.reglages.ecranAllume);
    if (!a.echauffement) return echauffement(app, a);
    if (!a.exercices.length) return h('div', {}, h('h1', {}, 'Séance vide'), FM.btn('Abandonner la séance', () => annuler(app), 'danger geant'));
    a.index = Math.min(a.index, a.exercices.length - 1);
    const entree = a.exercices[a.index], ex = FM.EX[entree.exId], it = entree.prevu;
    if (chrono && chrono.exId !== entree.exId) chrono = null;
    const aller = i => { a.index = i; chrono = null; app.sauver(); app.rendre(); window.scrollTo(0, 0); };
    const total = a.exercices.reduce((t, x) => t + x.series.length, 0);
    const faites = a.exercices.reduce((t, x) => t + x.series.filter(s => s.fait).length, 0);

    const vue = h('div', {},
      h('div', { class: 'entete' }, h('p', { class: 'surtitre' }, `${a.nom} · exercice ${a.index + 1} / ${a.exercices.length}`), FM.btn('Terminer', () => FM.terminerSeance(app), 'petit')),
      h('progress', { max: total || 1, value: faites, 'aria-label': `${faites} séries sur ${total}` }),
      h('h1', {}, ex.nom), h('p', { class: 'discret' }, FM.resumeItem(it) + (it.max && ex.mode !== 'temps' ? ' · garde 1 à 3 répétitions en réserve' : '')),
      h('div', { class: 'rangee' },
        FM.btn('Consignes', () => FM.modale(ex.nom, FM.fiche(ex))),
        FM.btn('Remplacer', () => remplacer(app, a, entree)),
        FM.btn('J’ai une douleur', () => signalerDouleur(app, a, entree), 'danger')));

    const hist = FM.historiqueExercice(e.seances, ex.id), dernier = hist[hist.length - 1];
    if (dernier) vue.append(h('p', {}, h('strong', {}, 'La dernière fois : '), dernier.series.map(s => FM.resumeSerie(ex, s)).join(' · ')));
    else if (ex.mode === 'charge') vue.append(h('p', { class: 'info' }, 'Première fois : choisis une charge légère qui te laisse 2 à 3 répétitions en réserve.'));
    const prop = FM.proposer(e.seances, ex.id, it);
    if (e.cibles[ex.id]) vue.append(h('p', { class: 'info' }, 'Objectif accepté appliqué : ' + FM.resumeSerie(ex, e.cibles[ex.id]) + '.'));
    else if (prop) vue.append(FM.carteProposition(app, ex, prop, () => {
      entree.series.forEach(s => { if (!s.fait) { s.kg = prop.cible.kg; s.reps = prop.cible.reps; } });
    }));

    const courante = entree.series.findIndex(s => !s.fait);
    entree.series.forEach((s, i) => {
      if (s.fait) {
        vue.append(h('div', { class: 'serie faite' }, h('span', {}, `✓ Série ${i + 1} : ${FM.resumeSerie(ex, s)}`),
          FM.btn('Corriger', () => { s.fait = false; app.sauver(); app.rendre(); }, 'petit')));
        return;
      }
      if (i !== courante) { vue.append(h('div', { class: 'serie attente' }, `Série ${i + 1} : ${FM.resumeSerie(ex, s)}`)); return; }
      const bloc = h('div', { class: 'serie active' }, h('h3', {}, `Série ${i + 1} sur ${entree.series.length}`));
      if (ex.mode === 'charge' || ex.lest) {
        bloc.append(FM.stepper({ label: FM.labelCharge(ex), valeur: s.kg, pas: ex.inc, min: 0, max: 1000, onchange: v => {
          const ancien = s.kg;
          entree.series.forEach((x, k) => { if (k > i && !x.fait && x.kg === ancien) x.kg = v; });
          s.kg = v; app.sauver();
          vue.querySelectorAll('.serie.attente').forEach((el, k) => { const n = i + 1 + k; el.textContent = `Série ${n + 1} : ${FM.resumeSerie(ex, entree.series[n])}`; });
        } }));
      }
      const champReps = FM.stepper({ label: (ex.mode === 'temps' ? 'Secondes' : 'Répétitions') + (ex.uni ? ' (par côté)' : ''), valeur: s.reps, pas: ex.mode === 'temps' ? 5 : 1, min: 0, max: 3600, onchange: v => { s.reps = Math.round(v); app.sauver(); } });
      bloc.append(champReps);
      if (ex.mode === 'temps') {
        const b = FM.btn(chrono ? 'Arrêter le chrono' : 'Lancer le chrono', () => {
          if (!chrono) {
            FM.timer.arreter();
            chrono = { debut: Date.now(), exId: ex.id };
            b.textContent = 'Arrêter le chrono'; tic();
          } else {
            s.reps = Math.round((Date.now() - chrono.debut) / 1000); chrono = null;
            champReps.definir(s.reps); b.textContent = 'Lancer le chrono'; affichage.textContent = ''; app.sauver();
          }
        }, 'geant');
        const affichage = h('p', { class: 'chrono', 'aria-live': 'off' });
        const tic = () => { if (!chrono || !affichage.isConnected) return; affichage.textContent = FM.mmss((Date.now() - chrono.debut) / 1000); setTimeout(tic, 250); };
        bloc.append(affichage, b);
        if (chrono) setTimeout(tic, 0);
      }
      bloc.append(FM.btn('Valider la série', () => {
        if (chrono) { s.reps = Math.round((Date.now() - chrono.debut) / 1000); chrono = null; }
        if (!(s.reps > 0)) return FM.toast(ex.mode === 'temps' ? 'Indique la durée.' : 'Indique le nombre de répétitions.');
        if (ex.mode === 'charge' && !(s.kg > 0)) return FM.toast('Indique la charge utilisée.');
        s.fait = true;
        const resteIci = entree.series.some(x => !x.fait);
        const resteAilleurs = a.exercices.some(x => x.series.some(y => !y.fait));
        if (resteAilleurs && it.repos > 0) FM.timer.demarrer(it.repos, resteIci ? `Ensuite : ${ex.nom}, série ${i + 2}` : 'Ensuite : exercice suivant');
        app.sauver(); app.rendre();
      }, 'primaire geant'));
      vue.append(bloc);
    });

    vue.append(h('div', { class: 'rangee' },
      FM.btn('+ Série', () => { const d = entree.series[entree.series.length - 1] || { kg: 0, reps: it.min }; entree.series.push({ kg: d.kg, reps: d.reps, fait: false }); app.sauver(); app.rendre(); }, '', { disabled: entree.series.length >= 12 }),
      FM.btn('− Série', () => { for (let k = entree.series.length - 1; k >= 0; k--) if (!entree.series[k].fait) { entree.series.splice(k, 1); break; } app.sauver(); app.rendre(); }, '', { disabled: courante < 0 || entree.series.length <= 1 })));

    if (entree.series.some(s => s.fait)) {
      vue.append(FM.carte(h('h3', {}, 'Ton ressenti sur cet exercice'),
        FM.choix([['facile', 'Facile'], ['correct', 'Correct'], ['difficile', 'Difficile'], ['echec', 'À l’échec']], entree.ressenti, v => { entree.ressenti = v; app.sauver(); }, 'Ressenti'),
        h('p', { class: 'discret' }, 'Sert à proposer la charge de la prochaine séance. Sans réponse : « Correct ».')));
    }

    const dernierEx = a.index === a.exercices.length - 1;
    vue.append(h('div', { class: 'rangee navigation' },
      FM.btn('← Précédent', () => aller(a.index - 1), '', { disabled: a.index === 0 }),
      dernierEx ? FM.btn('Terminer la séance', () => FM.terminerSeance(app), courante < 0 ? 'primaire' : '')
        : FM.btn('Suivant →', () => aller(a.index + 1), courante < 0 ? 'primaire' : '')),
      FM.btn('Abandonner la séance', () => annuler(app), 'lien'));
    return vue;
  };

  FM.carteProposition = function (app, ex, prop, apres) {
    const appliquable = prop.type !== 'douleur' || prop.cible.kg > 0;
    const c = h('div', { class: 'proposition ' + prop.type }, h('strong', {}, prop.titre), h('p', {}, prop.raison));
    if (appliquable) {
      const b = FM.btn(prop.type === 'douleur' ? `Reprendre à ${FM.fmt(prop.cible.kg)} kg (sans douleur seulement)` : `Appliquer : ${FM.resumeSerie(ex, prop.cible)}`, () => {
        app.etat.cibles[ex.id] = { kg: prop.cible.kg, reps: prop.cible.reps, depuis: Date.now() };
        if (apres) apres();
        app.sauver(); app.rendre(); FM.toast('Objectif enregistré.');
      }, '');
      c.append(b);
    }
    return c;
  };

  FM.vues.bilan = function (app, id) {
    const e = app.etat, s = e.seances.find(x => x.id === id);
    if (!s) return h('div', {}, h('h1', {}, 'Séance introuvable'), FM.lien('#/suivi', 'Historique', 'btn'));
    const series = s.exercices.reduce((t, x) => t + x.series.length, 0);
    const volume = s.exercices.reduce((t, x) => t + FM.stats(x.series).volume, 0);
    const records = FM.nouveauxRecords(e.seances, s);
    const derniere = [...e.seances].sort((a, b) => b.debut - a.debut)[0] === s;
    const vue = h('div', {}, h('p', { class: 'surtitre' }, FM.dateLongue(s.debut)), h('h1', {}, 'Séance terminée'),
      h('div', { class: 'tuiles' },
        h('div', { class: 'tuile' }, h('strong', {}, `${Math.max(1, Math.round((s.fin - s.debut) / 60000))} min`), h('span', {}, 'durée')),
        h('div', { class: 'tuile' }, h('strong', {}, String(series)), h('span', {}, 'séries')),
        h('div', { class: 'tuile' }, h('strong', {}, `${FM.fmt(volume)} kg`), h('span', {}, 'volume saisi'))));
    if (records.length) vue.append(FM.carte(h('h2', {}, 'Nouveaux records 🏆'), h('ul', {}, records.map(r => h('li', {}, `${FM.EX[r.exId].nom} — ${r.nom.toLowerCase()} : ${FM.fmt(r.valeur)} ${r.unite} (avant : ${FM.fmt(r.avant)})`)))));
    if (derniere) {
      const bloc = FM.carte(h('h2', {}, 'Pour la prochaine fois'), h('p', { class: 'discret' }, 'Rien ne change tant que tu n’appuies pas sur « Appliquer ».'));
      for (const x of s.exercices) {
        const p = FM.proposer(e.seances, x.exId, x.prevu || FM.item(x.exId, e.profil));
        if (!p) continue;
        bloc.append(h('h3', {}, FM.EX[x.exId].nom), e.cibles[x.exId] ? h('p', { class: 'info' }, '✓ Objectif enregistré : ' + FM.resumeSerie(FM.EX[x.exId], e.cibles[x.exId])) : FM.carteProposition(app, FM.EX[x.exId], p));
      }
      vue.append(bloc);
    }
    vue.append(FM.carte(h('h2', {}, 'Retour au calme (5 min)'), h('ul', {}, ['Marche ou vélo très léger 2 min.', 'Étirement doux des pectoraux contre un mur, 30 s par côté.', 'Fléchisseurs de hanche et ischios, 30 s par côté.', 'Avant-bras : paume vers le haut puis vers le bas, 30 s.', 'Respiration lente, 1 min.'].map(t => h('li', {}, t)))),
      FM.champ('Note sur la séance', h('textarea', { rows: 3, maxlength: 1000, value: s.note, oninput: ev => { s.note = ev.target.value; app.sauver(); } })),
      FM.btn('Retour à l’accueil', () => app.aller('#/accueil'), 'primaire geant'));
    return vue;
  };
})(typeof window !== 'undefined' ? window : globalThis);
