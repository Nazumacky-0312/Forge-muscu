/* Petits outils d'interface (aucun HTML injecté depuis les données). */
(function (root) {
  'use strict';
  const FM = root.FM || (root.FM = {});

  function h(tag, attrs, ...enfants) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'class') el.className = v;
      else if (k !== 'value') el.setAttribute(k, v === true ? '' : v);
    }
    for (const c of enfants.flat(Infinity)) if (c !== null && c !== undefined && c !== false) el.append(c.nodeType ? c : String(c));
    if (attrs && attrs.value !== undefined && attrs.value !== null) el.value = attrs.value; // après les <option>
    return el;
  }
  FM.h = h;

  FM.btn = (texte, onclick, classe, attrs) => h('button', Object.assign({ type: 'button', class: 'btn ' + (classe || ''), onclick }, attrs), texte);
  FM.carte = (...c) => h('section', { class: 'carte' }, ...c);
  FM.lien = (href, texte, classe) => h('a', { href, class: classe || '' }, texte);

  FM.toast = function (message) {
    const zone = document.getElementById('toasts');
    while (zone.children.length > 1) zone.firstChild.remove();
    const t = h('div', { class: 'toast' }, message);
    zone.append(t);
    setTimeout(() => t.remove(), 4000);
  };

  /* Fenêtre modale : actions = [{texte, classe, action}] ; une action qui renvoie false garde la fenêtre. */
  FM.modale = function (titre, contenu, actions) {
    const d = h('dialog', { class: 'modale' });
    const fermer = () => { if (d.open) d.close(); d.remove(); };
    d.append(h('h2', {}, titre), h('div', { class: 'modale-corps' }, contenu), h('div', { class: 'modale-actions' },
      (actions || [{ texte: 'Fermer' }]).map(a => FM.btn(a.texte, () => { if (!a.action || a.action() !== false) fermer(); }, a.classe))));
    d.addEventListener('cancel', e => { e.preventDefault(); fermer(); });
    document.body.append(d);
    d.showModal();
    return fermer;
  };
  FM.confirmer = (titre, message, oui, action, danger) => FM.modale(titre, h('p', {}, message), [
    { texte: oui, classe: danger ? 'danger' : 'primaire', action }, { texte: 'Annuler' }]);

  /* Champ numérique avec gros boutons − et +. */
  FM.stepper = function ({ label, valeur, pas, min, max, onchange, onfin }) {
    const borne = v => Math.round(Math.min(max, Math.max(min, v)) * 100) / 100;
    let courant = borne(valeur);
    const input = h('input', { type: 'text', inputmode: 'decimal', 'aria-label': label, value: FM.fmt(courant) });
    const poser = v => { courant = borne(v); input.value = FM.fmt(courant); onchange(courant); if (onfin) onfin(courant); };
    input.addEventListener('input', () => { const v = parseFloat(input.value.replace(',', '.')); if (Number.isFinite(v)) { courant = borne(v); onchange(courant); } });
    input.addEventListener('change', () => { input.value = FM.fmt(courant); if (onfin) onfin(courant); });
    input.addEventListener('focus', () => input.select());
    const el = h('div', { class: 'stepper' }, h('span', { class: 'stepper-label' }, label), h('div', { class: 'stepper-ligne' },
      FM.btn('−', () => poser(courant - pas), 'rond', { 'aria-label': 'Diminuer ' + label }), input,
      FM.btn('+', () => poser(courant + pas), 'rond', { 'aria-label': 'Augmenter ' + label })));
    el.definir = v => { courant = borne(v); input.value = FM.fmt(courant); };
    return el;
  };

  FM.choix = function (options, valeur, onchange, nom) {
    const g = h('div', { class: 'puces', role: 'group', 'aria-label': nom });
    options.forEach(([v, t]) => {
      const b = FM.btn(t, () => { [...g.children].forEach(c => c.setAttribute('aria-pressed', 'false')); b.setAttribute('aria-pressed', 'true'); onchange(v); }, 'puce', { 'aria-pressed': String(v === valeur) });
      g.append(b);
    });
    return g;
  };
  FM.cases = function (options, liste, onchange, nom) {
    return h('div', { class: 'puces', role: 'group', 'aria-label': nom }, options.map(([v, t]) => {
      const b = FM.btn(t, () => {
        const i = liste.indexOf(v);
        if (i >= 0) liste.splice(i, 1); else liste.push(v);
        b.setAttribute('aria-pressed', String(i < 0));
        if (onchange) onchange(liste);
      }, 'puce', { 'aria-pressed': String(liste.includes(v)) });
      return b;
    }));
  };
  FM.champ = (label, controle) => {
    controle.setAttribute('aria-label', label); // nom lisible, sans le texte des options
    return h('label', { class: 'champ' }, h('span', {}, label), controle);
  };

  FM.dateCourte = ts => new Date(ts).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
  FM.dateLongue = ts => new Date(ts).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
  FM.cleJour = ts => { const d = new Date(ts); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
  FM.lundi = ts => { const d = new Date(ts); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d; };
  FM.mmss = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  FM.unite = ex => (ex.mode === 'temps' ? 's' : 'rép.');
  FM.resumeSerie = (ex, s) => (s.kg > 0 ? `${FM.fmt(s.kg)} kg × ` : '') + s.reps + (ex.mode === 'temps' ? ' s' : (s.kg > 0 ? '' : ' rép.'));
  FM.resumeItem = it => `${it.series} × ${it.min}${it.max !== it.min ? '–' + it.max : ''} ${FM.unite(FM.EX[it.exId])}${FM.EX[it.exId].uni ? ' / côté' : ''} · repos ${FM.mmss(it.repos)}`;
  FM.labelCharge = ex => (ex.mode === 'charge' ? (ex.parHaltere ? 'kg par haltère' : 'Charge (kg)') : (ex.parHaltere ? 'kg par haltère' : 'Lest (kg)'));

  FM.telecharger = function (nom, contenu) {
    const url = URL.createObjectURL(new Blob([contenu], { type: 'application/json' }));
    const a = h('a', { href: url, download: nom });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  };

  /* Choix d'un exercice dans une liste, avec recherche. */
  FM.choisirExercice = function (titre, ids, onchoix) {
    const liste = h('div', { class: 'liste' });
    let fermer;
    const sans = s => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    const remplir = q => liste.replaceChildren(...(ids.map(i => FM.EX[i]).filter(e => sans(e.nom + ' ' + e.muscles.map(m => FM.MUSCLES[m]).join(' ')).includes(sans(q)))
      .map(e => FM.btn([h('strong', {}, e.nom), h('small', {}, e.muscles.map(m => FM.MUSCLES[m]).join(', '))], () => { fermer(); onchoix(e.id); }, 'ligne'))));
    const q = h('input', { type: 'search', placeholder: 'Rechercher…', 'aria-label': 'Rechercher un exercice', oninput: e => remplir(e.target.value) });
    remplir('');
    if (!ids.length) liste.append(h('p', {}, 'Aucun exercice compatible avec ton matériel.'));
    fermer = FM.modale(titre, [q, liste], [{ texte: 'Annuler' }]);
  };
})(typeof window !== 'undefined' ? window : globalThis);
