/* Profil, réglages, sauvegarde. */
(function (root) {
  'use strict';
  const FM = root.FM, h = FM.h;
  let brouillon = null;

  const signature = p => JSON.stringify([p.objectif, p.niveau, p.jours, p.duree, [...p.materiel].sort(), [...p.priorites].sort()]);

  FM.vues.profil = function (app) {
    const e = app.etat;
    if (!brouillon) brouillon = JSON.parse(JSON.stringify(e.profil));
    const p = brouillon;
    const jours = [[1, 'Lun'], [2, 'Mar'], [3, 'Mer'], [4, 'Jeu'], [5, 'Ven'], [6, 'Sam'], [0, 'Dim']];

    const enregistrer = () => {
      if (p.joursSemaine.length !== p.jours) return FM.toast(`Choisis exactement ${p.jours} jours d’entraînement (${p.joursSemaine.length} sélectionnés).`);
      const change = signature(p) !== signature(e.profil);
      p.prenom = p.prenom.trim(); p.joursSemaine.sort();
      e.profil = JSON.parse(JSON.stringify(p)); app.sauver(); FM.toast('Profil enregistré.');
      if (change) {
        FM.modale('Mettre le programme à jour ?', h('p', {}, 'Ton profil a changé. Générer un nouveau programme remplacera tes modifications. L’historique reste.'), [
          { texte: 'Générer un nouveau programme', classe: 'primaire', action: () => { FM.regenerer(app); app.aller('#/programme'); } },
          { texte: 'Garder mon programme' }]);
      }
    };

    const vue = h('div', {}, h('h1', {}, 'Profil et réglages'),
      FM.carte(h('h2', {}, 'Mon profil'),
        FM.champ('Prénom', h('input', { type: 'text', maxlength: 40, value: p.prenom, oninput: ev => { p.prenom = ev.target.value; } })),
        h('h3', {}, 'Objectif'), FM.choix([['muscle', 'Physique musclé et défini'], ['force', 'Force'], ['seche', 'Définition / endurance']], p.objectif, v => { p.objectif = v; }, 'Objectif'),
        h('h3', {}, 'Niveau'), FM.choix([['debutant', 'Débutant'], ['intermediaire', 'Intermédiaire'], ['avance', 'Avancé']], p.niveau, v => { p.niveau = v; }, 'Niveau'),
        h('h3', {}, 'Séances par semaine'), FM.choix([[3, '3'], [4, '4']], p.jours, v => { p.jours = v; p.joursSemaine = FM.joursParDefaut(v); app.rendre(); }, 'Séances par semaine'),
        h('h3', {}, 'Jours d’entraînement'), FM.cases(jours, p.joursSemaine, null, 'Jours d’entraînement'),
        h('h3', {}, 'Durée d’une séance'), FM.choix([[30, '30 min'], [45, '45 min'], [60, '60 min']], p.duree, v => { p.duree = v; }, 'Durée'),
        h('h3', {}, 'Priorités'), FM.cases(Object.entries(FM.PRIORITES), p.priorites, null, 'Priorités'),
        h('h3', {}, 'Matériel disponible'),
        h('div', { class: 'rangee' }, Object.values(FM.PRESETS).map(x => FM.btn(x.nom, () => { p.materiel = [...x.materiel]; app.rendre(); }))),
        FM.cases(Object.entries(FM.MATERIEL), p.materiel, null, 'Matériel'),
        h('p', { class: 'discret' }, 'Le poids du corps est toujours inclus.'),
        FM.btn('Enregistrer le profil', enregistrer, 'primaire geant')));

    const reg = e.reglages;
    const interrupteur = (cle, texte, aide, apres) => h('div', {}, h('label', { class: 'case' }, h('input', { type: 'checkbox', checked: reg[cle], onchange: ev => { reg[cle] = ev.target.checked; app.sauver(); if (apres) apres(); } }), texte), aide ? h('p', { class: 'discret' }, aide) : null);
    const permission = 'Notification' in root ? root.Notification.permission : 'absente';
    vue.append(FM.carte(h('h2', {}, 'Minuteur de repos'),
      interrupteur('son', 'Son à la fin du repos', null, () => { if (e.repos) FM.timer.armer(); }),
      interrupteur('ecranEteint', 'Sonner même écran éteint', 'Le repos est lu comme un son (silence puis bips). Cela peut mettre ta musique en pause. Décoche pour garder la musique : le bip n’est alors fiable qu’avec l’écran allumé.', () => { if (e.repos) FM.timer.armer(); }),
      interrupteur('vibration', 'Vibration (écran allumé)'),
      interrupteur('ecranAllume', 'Garder l’écran allumé pendant la séance', null, () => FM.ecran(false)),
      interrupteur('notifications', 'Notification si l’appli est en arrière-plan', permission === 'denied' ? 'Notifications bloquées : autorise-les dans les réglages du navigateur.' : permission === 'absente' ? 'Ce navigateur ne propose pas les notifications.' : 'Complément du son : le téléphone peut la retarder écran éteint.', async () => {
        if (!reg.notifications) return;
        const r = 'Notification' in root ? await root.Notification.requestPermission() : 'denied';
        if (r !== 'granted') { reg.notifications = false; app.sauver(); FM.toast('Notifications non autorisées.'); }
        app.rendre();
      }),
      FM.btn('Tester : repos de 10 secondes', () => { FM.timer.demarrer(10, 'Test du minuteur'); FM.toast('Éteins l’écran pour vérifier que tu entends les bips.'); }, 'geant')));

    const fichier = h('input', { type: 'file', accept: '.json,application/json', class: 'cache', 'aria-label': 'Fichier de sauvegarde', onchange: async ev => {
      const f = ev.target.files[0];
      ev.target.value = '';
      if (!f) return;
      try {
        if (f.size > 10e6) throw new Error('Fichier trop volumineux.');
        const neuf = FM.store.importer(await f.text());
        FM.confirmer('Remplacer les données ?', `Le fichier contient ${neuf.seances.length} séance(s) et ${neuf.cardio.length} activité(s). Les données actuelles de cet appareil seront remplacées.`, 'Importer', () => {
          FM.timer.arreter(); app.etat = neuf; brouillon = null; app.sauver(); app.aller('#/accueil'); FM.toast('Données importées.');
        }, true);
      } catch (err) { FM.toast(err.message); }
    } });
    vue.append(FM.carte(h('h2', {}, 'Mes données'),
      h('p', { class: 'discret' }, `${e.seances.length} séance(s), ${e.cardio.length} activité(s). Dernier export : ${e.dernierExport ? FM.dateCourte(e.dernierExport) : 'jamais'}.`),
      FM.btn('Exporter en JSON', () => { app.exporter(); app.rendre(); }, 'geant'),
      FM.btn('Importer un fichier JSON', () => fichier.click(), 'geant'), fichier,
      FM.btn('Tout effacer', () => FM.confirmer('Tout effacer ?', 'Profil, programme, historique et records seront supprimés définitivement. Exporte d’abord si tu veux les garder.', 'Tout effacer', () => {
        FM.timer.arreter(); app.etat = FM.etatInitial(); brouillon = null; app.sauver(); app.aller('#/accueil');
      }, true), 'danger geant')));

    vue.append(FM.carte(h('h2', {}, 'Application'),
      app.invite ? FM.btn('Installer l’application', () => app.installer(), 'primaire geant')
        : h('p', { class: 'discret' }, root.matchMedia('(display-mode: standalone)').matches ? 'Application installée.' : 'Pour installer : menu du navigateur → « Installer l’application » ou « Ajouter à l’écran d’accueil ».'),
      h('p', {}, app.horsLigne ? '✓ Prête à fonctionner hors ligne.' : 'Mode hors ligne pas encore actif (il demande une adresse https ou localhost, puis un premier chargement).')),
      FM.carte(h('h2', {}, 'Sécurité'), h('ul', {}, ['Échauffe-toi avant chaque séance et respecte les temps de repos.', 'Douleur vive ou articulaire : arrête l’exercice.', 'Douleur dans la poitrine, malaise, essoufflement anormal : stop, appelle le 15 ou le 112.', 'En cas de problème de santé ou de reprise après une longue pause, demande un avis médical.', 'Cette application ne remplace ni un médecin ni un coach présent à tes côtés.'].map(t => h('li', {}, t)))));
    return vue;
  };
  FM.oublierBrouillonProfil = () => { brouillon = null; };
})(typeof window !== 'undefined' ? window : globalThis);
