/* Données : muscles, matériel, exercices. */
(function (root) {
  'use strict';
  const FM = root.FM || (root.FM = {});

  FM.MUSCLES = {
    pectoraux: 'Pectoraux', epaules: 'Épaules', trapezes: 'Trapèzes', avantbras: 'Avant-bras',
    abdos: 'Abdominaux', dos: 'Dos', biceps: 'Biceps', triceps: 'Triceps',
    quadriceps: 'Quadriceps', ischios: 'Ischio-jambiers', fessiers: 'Fessiers', mollets: 'Mollets'
  };
  FM.PRIORITES = {
    pectoraux: 'Pectoraux', epaules: 'Épaules', avantbras: 'Avant-bras', trapezes: 'Trapèzes',
    abdos: 'Abdominaux', dos: 'Dos', biceps: 'Biceps', triceps: 'Triceps', jambes: 'Jambes'
  };
  FM.MATERIEL = {
    halteres: 'Haltères', barre: 'Barre + disques', rack: 'Rack à squat', banc: 'Banc réglable',
    poulie: 'Poulie', machines: 'Machines guidées', traction: 'Barre de traction',
    paralleles: 'Barres à dips', elastiques: 'Élastiques', roulette: 'Roulette abdos'
  };
  FM.PRESETS = {
    salle: { nom: 'Salle complète', materiel: Object.keys(FM.MATERIEL) },
    maison: { nom: 'Haltères + banc', materiel: ['halteres', 'banc'] },
    corps: { nom: 'Poids du corps', materiel: [] }
  };

  const list = [];
  /*
   * equip : « a+b|c » = (a ET b) OU c ; '' = poids du corps.
   * mode  : charge (kg × répétitions), reps (répétitions, lest facultatif), temps (secondes).
   */
  function E(id, nom, pattern, muscles, secondaires, equip, mode, niveau, consignes, erreurs, alternatives, opts) {
    list.push(Object.assign({
      id, nom, pattern, muscles: muscles.split(' '),
      secondaires: secondaires ? secondaires.split(' ') : [],
      equip: equip ? equip.split('|').map(s => s.split('+')) : [[]],
      mode, niveau, consignes, erreurs, alternatives: alternatives.split(' '),
      poly: false, inc: 2, uni: false, lest: mode === 'charge', parHaltere: false
    }, opts || {}));
  }

  /* Pectoraux */
  E('dc_barre', 'Développé couché barre', 'pouss_h', 'pectoraux', 'triceps epaules', 'barre+banc+rack', 'charge', 2,
    ['Omoplates serrées et basses, pieds ancrés au sol.', 'Descends la barre vers le bas des pectoraux, coudes à environ 45–70° du buste.', 'Pousse en soufflant, poignets au-dessus des coudes.', 'Utilise les sécurités du rack ou un pareur.'],
    ['Faire rebondir la barre sur la poitrine.', 'Écarter les coudes à 90°.', 'Décoller les fesses du banc.'], 'dc_halteres presse_pecs pompes', { poly: true, inc: 2.5 });
  E('dc_halteres', 'Développé couché haltères', 'pouss_h', 'pectoraux', 'triceps epaules', 'halteres+banc', 'charge', 1,
    ['Haltères au-dessus de la poitrine, omoplates serrées.', 'Descends jusqu’à sentir l’étirement des pectoraux, sans douleur à l’épaule.', 'Remonte sans entrechoquer les haltères.'],
    ['Descendre bien plus bas que ce que l’épaule tolère.', 'Perdre le serrage des omoplates.', 'Lâcher les haltères de haut en fin de série.'], 'dc_barre presse_pecs pompes', { poly: true, parHaltere: true });
  E('presse_pecs', 'Presse pectoraux à la machine', 'pouss_h', 'pectoraux', 'triceps epaules', 'machines', 'charge', 1,
    ['Règle le siège : poignées à hauteur du milieu de la poitrine.', 'Dos plaqué, omoplates serrées.', 'Pousse puis reviens lentement.'],
    ['Épaules qui partent vers l’avant.', 'Verrouiller violemment les coudes.'], 'dc_halteres dc_barre pompes', { poly: true, inc: 5 });
  E('di_halteres', 'Développé incliné haltères', 'pouss_inc', 'pectoraux epaules', 'triceps', 'halteres+banc', 'charge', 1,
    ['Banc incliné à 30° environ.', 'Descends les haltères au niveau du haut de la poitrine, coudes sous les poignets.', 'Pousse vers le haut en gardant les omoplates serrées.'],
    ['Banc trop vertical : les épaules prennent tout.', 'Cambrer exagérément le bas du dos.'], 'di_barre pompes_declinees presse_pecs', { poly: true, parHaltere: true });
  E('di_barre', 'Développé incliné barre', 'pouss_inc', 'pectoraux epaules', 'triceps', 'barre+banc+rack', 'charge', 2,
    ['Banc à 30°, omoplates serrées.', 'Descends la barre sur le haut de la poitrine.', 'Pousse à la verticale, avec sécurités en place.'],
    ['Faire rebondir la barre.', 'Prise beaucoup trop large.'], 'di_halteres pompes_declinees', { poly: true, inc: 2.5 });
  E('pompes', 'Pompes', 'pouss_h', 'pectoraux', 'triceps epaules abdos', '', 'reps', 1,
    ['Mains un peu plus larges que les épaules, corps gainé en ligne droite.', 'Descends la poitrine près du sol, coudes à environ 45°.', 'Pousse le sol sans casser l’alignement.'],
    ['Bassin qui s’affaisse.', 'Amplitude partielle.', 'Tête qui plonge vers l’avant.'], 'pompes_inclinees pompes_declinees dc_halteres', { poly: true });
  E('pompes_inclinees', 'Pompes mains surélevées', 'pouss_h', 'pectoraux', 'triceps epaules', '', 'reps', 1,
    ['Mains sur un support stable (banc, table lourde).', 'Corps aligné, descends la poitrine vers le support.', 'Plus le support est haut, plus c’est facile.'],
    ['Support instable ou glissant.', 'Hanches pliées.'], 'pompes presse_pecs', { poly: true });
  E('pompes_declinees', 'Pompes pieds surélevés', 'pouss_inc', 'pectoraux epaules', 'triceps abdos', '', 'reps', 2,
    ['Pieds sur un support stable, mains au sol.', 'Gaine fort, descends en contrôle.', 'Pousse sans cambrer.'],
    ['Cambrer le bas du dos.', 'Support trop haut qui transforme le mouvement en poussée d’épaules.'], 'pompes di_halteres pompes_piquees', { poly: true });
  E('dips', 'Dips aux barres parallèles', 'dips', 'pectoraux triceps', 'epaules', 'paralleles', 'reps', 2,
    ['Départ bras tendus, épaules basses.', 'Buste légèrement penché, descends jusqu’à environ 90° de flexion du coude.', 'Remonte sans à-coups.'],
    ['Descendre trop bas et tirer sur l’avant de l’épaule.', 'Hausser les épaules.', 'Se balancer.'], 'pompes ecarte_poulie pompes_declinees', { poly: true, lest: true, inc: 2.5 });
  E('ecarte_poulie', 'Écarté à la poulie', 'ecarte', 'pectoraux', 'epaules', 'poulie', 'charge', 1,
    ['Un pas devant les poulies, coudes légèrement fléchis.', 'Ramène les mains devant la poitrine en dessinant un arc.', 'Contrôle le retour jusqu’à l’étirement.'],
    ['Transformer l’écarté en développé.', 'Charge trop lourde qui tire les épaules en arrière.'], 'pec_deck ecarte_halteres pompes', { inc: 2.5 });
  E('pec_deck', 'Pec deck (butterfly)', 'ecarte', 'pectoraux', '', 'machines', 'charge', 1,
    ['Poignées à hauteur de poitrine, dos plaqué.', 'Rapproche les bras, marque une seconde.', 'Reviens lentement sans dépasser l’alignement des épaules.'],
    ['Ouvrir trop loin en arrière.', 'Décoller le dos pour tricher.'], 'ecarte_poulie ecarte_halteres', { inc: 5 });
  E('ecarte_halteres', 'Écarté couché haltères', 'ecarte', 'pectoraux', 'epaules', 'halteres+banc', 'charge', 2,
    ['Coudes légèrement fléchis et fixes.', 'Ouvre les bras jusqu’à un étirement confortable.', 'Referme sans cogner les haltères.'],
    ['Descendre trop bas.', 'Charger comme sur un développé.'], 'ecarte_poulie pec_deck', { parHaltere: true, inc: 1 });

  /* Épaules */
  E('dm_barre', 'Développé militaire barre', 'pouss_v', 'epaules', 'triceps trapezes abdos', 'barre+rack', 'charge', 2,
    ['Debout, fessiers et abdos serrés.', 'Barre au niveau des clavicules, avance la tête une fois la barre passée.', 'Termine bras tendus au-dessus de la tête.'],
    ['Cambrer le bas du dos.', 'Pousser la barre loin devant.'], 'de_halteres presse_epaules pompes_piquees', { poly: true, inc: 2.5 });
  E('de_halteres', 'Développé épaules haltères', 'pouss_v', 'epaules', 'triceps trapezes', 'halteres', 'charge', 1,
    ['Assis dossier haut ou debout gainé.', 'Haltères à hauteur d’oreilles, coudes un peu devant le buste.', 'Pousse vers le haut puis redescends lentement.'],
    ['Cambrer pour monter la charge.', 'Coudes tirés loin derrière.'], 'dm_barre presse_epaules pompes_piquees', { poly: true, parHaltere: true });
  E('presse_epaules', 'Presse épaules à la machine', 'pouss_v', 'epaules', 'triceps', 'machines', 'charge', 1,
    ['Poignées au niveau des épaules au départ.', 'Dos collé au dossier.', 'Pousse sans verrouiller brutalement.'],
    ['Siège mal réglé.', 'Décoller le dos.'], 'de_halteres dm_barre', { poly: true, inc: 5 });
  E('pompes_piquees', 'Pompes piquées', 'pouss_v', 'epaules', 'triceps trapezes', '', 'reps', 2,
    ['Hanches hautes, corps en V inversé.', 'Descends la tête devant les mains.', 'Pousse pour revenir en V.'],
    ['Laisser les hanches descendre.', 'Écarter les coudes à l’extrême.'], 'de_halteres pompes_declinees', { poly: true });
  E('lat_halteres', 'Élévations latérales haltères', 'elev_lat', 'epaules', 'trapezes', 'halteres', 'charge', 1,
    ['Léger fléchissement des coudes.', 'Monte les bras sur les côtés jusqu’à la hauteur des épaules.', 'Redescends en 2 à 3 secondes.'],
    ['Prendre de l’élan.', 'Hausser les épaules.', 'Charge trop lourde.'], 'lat_poulie lat_elastique', { parHaltere: true, inc: 1 });
  E('lat_poulie', 'Élévation latérale à la poulie', 'elev_lat', 'epaules', '', 'poulie', 'charge', 1,
    ['Poulie basse, câble qui passe devant ou derrière le corps.', 'Monte jusqu’à l’épaule, coude souple.', 'Fais les deux côtés.'],
    ['Pencher le buste pour tricher.', 'Tirer avec la main au lieu du coude.'], 'lat_halteres lat_elastique', { uni: true, inc: 1.25 });
  E('lat_elastique', 'Élévations latérales élastique', 'elev_lat', 'epaules', '', 'elastiques', 'reps', 1,
    ['Élastique sous les pieds.', 'Monte les bras jusqu’aux épaules.', 'Résiste au retour.'],
    ['Élan du buste.', 'Élastique mal coincé.'], 'lat_halteres lat_poulie');
  E('oiseau', 'Oiseau haltères (arrière d’épaule)', 'arriere', 'epaules', 'trapezes dos', 'halteres', 'charge', 1,
    ['Buste penché, dos plat.', 'Écarte les bras en menant avec les coudes.', 'Pause brève en haut.'],
    ['Dos rond.', 'Se redresser à chaque répétition.'], 'face_pull pec_deck_inverse ytw_sol', { parHaltere: true, inc: 1 });
  E('face_pull', 'Face pull à la poulie', 'arriere', 'epaules trapezes', 'dos', 'poulie', 'charge', 1,
    ['Corde à hauteur du visage.', 'Tire vers le front en écartant les mains, coudes hauts.', 'Contrôle le retour.'],
    ['Charge trop lourde.', 'Cambrer en reculant.'], 'oiseau pec_deck_inverse ytw_sol', { inc: 2.5 });
  E('pec_deck_inverse', 'Pec deck inversé', 'arriere', 'epaules', 'trapezes dos', 'machines', 'charge', 1,
    ['Poitrine contre le dossier.', 'Ouvre les bras vers l’arrière.', 'Reviens lentement.'],
    ['Hausser les épaules.', 'Donner des à-coups.'], 'face_pull oiseau', { inc: 5 });

  /* Trapèzes */
  E('shrug_halteres', 'Shrugs haltères', 'shrug', 'trapezes', 'avantbras', 'halteres', 'charge', 1,
    ['Bras tendus le long du corps.', 'Monte les épaules vers les oreilles, verticalement.', 'Tiens 1 à 2 secondes, redescends à fond.'],
    ['Faire rouler les épaules.', 'Plier les coudes.', 'Avancer la tête.'], 'shrug_barre shrug_elastique farmer', { parHaltere: true, inc: 2 });
  E('shrug_barre', 'Shrugs barre', 'shrug', 'trapezes', 'avantbras', 'barre', 'charge', 1,
    ['Prise largeur d’épaules, barre contre les cuisses.', 'Monte les épaules droit vers le haut.', 'Pause en haut, descente contrôlée.'],
    ['Rouler les épaules.', 'Donner une impulsion avec les jambes.'], 'shrug_halteres shrug_elastique', { inc: 5 });
  E('shrug_elastique', 'Shrugs élastique', 'shrug', 'trapezes', '', 'elastiques', 'reps', 1,
    ['Élastique sous les pieds, bras tendus.', 'Monte les épaules et tiens 2 secondes.'],
    ['Plier les coudes.', 'Aller trop vite.'], 'shrug_halteres ytw_sol');
  E('ytw_sol', 'Élévations Y-T-W au sol', 'arriere', 'trapezes epaules', 'dos', '', 'reps', 1,
    ['Allongé sur le ventre, front près du sol.', 'Lève les bras en Y, puis en T, puis en W : cela compte pour 1 répétition.', 'Serre les omoplates à chaque lettre.'],
    ['Cambrer fort le bas du dos.', 'Relever la tête.'], 'face_pull oiseau');
  E('farmer', 'Marche du fermier', 'portage', 'avantbras trapezes', 'abdos', 'halteres', 'temps', 1,
    ['Deux haltères lourds, posture droite, épaules basses et en arrière.', 'Marche à petits pas réguliers.', 'Pose les charges avant que la prise lâche brusquement, dos plat.'],
    ['Dos rond en soulevant ou en posant.', 'Se pencher d’un côté.', 'Marcher dans un espace encombré.'], 'suspension serviette shrug_halteres', { lest: true, parHaltere: true });

  /* Dos */
  E('tractions', 'Tractions', 'tir_v', 'dos', 'biceps avantbras', 'traction', 'reps', 2,
    ['Départ bras tendus, épaules engagées.', 'Tire les coudes vers les hanches, menton au-dessus de la barre.', 'Descends en contrôle.'],
    ['Se balancer.', 'Amplitude partielle.', 'Se laisser tomber en bas.'], 'tirage_vertical rowing_inverse tirage_elastique', { poly: true, lest: true, inc: 2.5 });
  E('tirage_vertical', 'Tirage vertical à la poulie', 'tir_v', 'dos', 'biceps avantbras', 'poulie|machines', 'charge', 1,
    ['Cuisses calées, poitrine haute.', 'Tire la barre vers le haut de la poitrine.', 'Remonte jusqu’à bras presque tendus.'],
    ['Tirer derrière la nuque.', 'Se coucher en arrière.'], 'tractions tirage_elastique', { poly: true, inc: 5 });
  E('tirage_elastique', 'Tirage vertical élastique', 'tir_v', 'dos', 'biceps', 'elastiques', 'reps', 1,
    ['Élastique fixé solidement en hauteur.', 'À genoux, tire les coudes vers les côtes.', 'Résiste au retour.'],
    ['Point d’ancrage fragile.', 'Tirer avec les seuls biceps.'], 'tirage_vertical tractions', { poly: true });
  E('rowing_haltere', 'Rowing haltère un bras', 'tir_h', 'dos', 'biceps trapezes avantbras', 'halteres', 'charge', 1,
    ['Une main en appui, dos plat.', 'Tire le coude vers la hanche.', 'Étire en bas sans tourner le buste.'],
    ['Pivoter le buste.', 'Dos arrondi.'], 'rowing_poulie rowing_barre rowing_inverse', { poly: true, uni: true, parHaltere: true });
  E('rowing_barre', 'Rowing barre buste penché', 'tir_h', 'dos', 'biceps trapezes', 'barre', 'charge', 2,
    ['Hanches en arrière, dos neutre, buste à environ 45°.', 'Tire la barre vers le nombril.', 'Redescends sans bouger le buste.'],
    ['Dos rond.', 'Se redresser pour lancer la barre.'], 'rowing_haltere rowing_poulie', { poly: true, inc: 2.5 });
  E('rowing_poulie', 'Rowing assis à la poulie', 'tir_h', 'dos', 'biceps trapezes', 'poulie|machines', 'charge', 1,
    ['Assis grand, genoux souples.', 'Tire vers le ventre, serre les omoplates.', 'Allonge les bras sans arrondir le bas du dos.'],
    ['Balancer le buste.', 'Épaules vers les oreilles.'], 'rowing_haltere rowing_barre', { poly: true, inc: 5 });
  E('rowing_inverse', 'Rowing inversé', 'tir_h', 'dos', 'biceps abdos', 'traction|rack', 'reps', 1,
    ['Sous une barre basse parfaitement fixée.', 'Corps gainé, tire la poitrine vers la barre.', 'Avance les pieds pour durcir.'],
    ['Utiliser un meuble instable.', 'Laisser tomber le bassin.'], 'rowing_haltere rowing_serviette', { poly: true });
  E('rowing_serviette', 'Tirage isométrique à la serviette', 'tir_h', 'dos', 'biceps avantbras', '', 'temps', 1,
    ['Assis jambes tendues, serviette passée sous les pieds.', 'Tire fort coudes vers l’arrière et maintiens, en respirant.'],
    ['Bloquer la respiration.', 'Arrondir le dos.'], 'rowing_inverse ytw_sol');

  /* Biceps et avant-bras */
  E('curl_marteau', 'Curl marteau haltères', 'marteau', 'biceps avantbras', '', 'halteres', 'charge', 1,
    ['Paumes face à face, coudes près du corps.', 'Monte sans bouger les épaules.', 'Descends en 2 à 3 secondes jusqu’à bras tendus.'],
    ['Balancer le buste.', 'Avancer les coudes.', 'Casser les poignets.'], 'marteau_poulie marteau_elastique curl_serviette', { parHaltere: true, inc: 1 });
  E('marteau_poulie', 'Curl marteau à la corde', 'marteau', 'biceps avantbras', '', 'poulie', 'charge', 1,
    ['Corde sur poulie basse, prise neutre.', 'Fléchis les coudes sans les déplacer.', 'Contrôle le retour.'],
    ['Se pencher en arrière.', 'Amplitude tronquée.'], 'curl_marteau marteau_elastique', { inc: 2.5 });
  E('marteau_elastique', 'Curl marteau élastique', 'marteau', 'biceps avantbras', '', 'elastiques', 'reps', 1,
    ['Élastique sous les pieds, prise neutre.', 'Monte les mains vers les épaules, coudes fixes.'],
    ['Élan.', 'Relâcher d’un coup.'], 'curl_marteau marteau_poulie');
  E('curl_serviette', 'Curl marteau isométrique serviette', 'marteau', 'biceps avantbras', '', '', 'temps', 1,
    ['Serviette sous un pied, une extrémité dans chaque main, coudes à 90°.', 'Tire vers le haut contre la résistance du pied et maintiens.'],
    ['Bloquer la respiration.', 'Hausser les épaules.'], 'curl_marteau marteau_elastique');
  E('curl_inverse', 'Curl inversé', 'avb_ext', 'avantbras', 'biceps', 'barre|halteres', 'charge', 1,
    ['Prise paumes vers le sol.', 'Monte sans casser les poignets.', 'Charge modérée.'],
    ['Charge excessive.', 'Poignets qui plient.'], 'ext_poignets serviette', { inc: 1 });
  E('curl_poignets', 'Flexion des poignets', 'avb_flex', 'avantbras', '', 'halteres|barre', 'charge', 1,
    ['Avant-bras posés sur les cuisses ou un banc, paumes vers le haut.', 'Fléchis les poignets sur toute l’amplitude confortable.', 'Mouvement lent.'],
    ['Charge trop lourde.', 'Décoller les avant-bras.'], 'suspension serviette', { parHaltere: true, inc: 1 });
  E('ext_poignets', 'Extension des poignets', 'avb_ext', 'avantbras', '', 'halteres|barre', 'charge', 1,
    ['Avant-bras posés, paumes vers le sol.', 'Relève les mains lentement.', 'Charge légère.'],
    ['Forcer en cas de gêne au coude.', 'Aller vite.'], 'curl_inverse serviette', { parHaltere: true, inc: 1 });
  E('suspension', 'Suspension à la barre', 'portage', 'avantbras', 'dos epaules', 'traction', 'temps', 1,
    ['Prise ferme, épaules légèrement engagées.', 'Respire et reste immobile.', 'Descends avant de glisser.'],
    ['Se laisser pendre épaules totalement relâchées si cela gêne.', 'Sauter de haut.'], 'farmer serviette', { lest: true, inc: 2.5 });
  E('serviette', 'Torsion de serviette', 'avb_flex', 'avantbras', '', '', 'temps', 1,
    ['Serviette (éventuellement humide) tenue devant toi.', 'Tords-la fort comme pour l’essorer, change de sens à mi-temps.'],
    ['Crisper les épaules.', 'Forcer sur un poignet douloureux.'], 'suspension curl_poignets');

  /* Triceps */
  E('triceps_poulie', 'Extension triceps à la poulie', 'triceps', 'triceps', '', 'poulie', 'charge', 1,
    ['Coudes collés au corps.', 'Tends les bras complètement.', 'Remonte jusqu’à environ 90°.'],
    ['Coudes qui bougent.', 'Pousser avec le poids du corps.'], 'triceps_nuque pompes_serrees', { inc: 2.5 });
  E('triceps_nuque', 'Extension triceps au-dessus de la tête', 'triceps', 'triceps', '', 'halteres', 'charge', 1,
    ['Un haltère tenu à deux mains au-dessus de la tête.', 'Descends derrière la nuque, coudes vers le plafond.', 'Tends sans cambrer.'],
    ['Coudes très écartés.', 'Cambrer le dos.'], 'triceps_poulie pompes_serrees', { inc: 2 });
  E('pompes_serrees', 'Pompes mains serrées', 'triceps', 'triceps', 'pectoraux epaules', '', 'reps', 1,
    ['Mains sous la poitrine, largeur d’épaules ou un peu moins.', 'Coudes près du corps.', 'Corps gainé.'],
    ['Mains collées qui gênent les poignets.', 'Bassin qui tombe.'], 'triceps_poulie triceps_nuque');

  /* Jambes */
  E('squat_barre', 'Squat barre', 'squat', 'quadriceps fessiers', 'ischios abdos', 'barre+rack', 'charge', 2,
    ['Barre sur le haut du dos, sécurités réglées.', 'Inspire, gaine, descends hanches et genoux ensemble.', 'Genoux dans l’axe des pieds, pousse tout le pied.'],
    ['Genoux qui rentrent.', 'Talons qui décollent.', 'Dos qui s’arrondit.'], 'goblet presse_cuisses squat_pdc', { poly: true, inc: 5 });
  E('goblet', 'Goblet squat', 'squat', 'quadriceps fessiers', 'abdos', 'halteres', 'charge', 1,
    ['Haltère contre la poitrine.', 'Descends entre les genoux, buste haut.', 'Remonte en poussant le sol.'],
    ['Buste qui s’effondre.', 'Genoux qui rentrent.'], 'squat_barre presse_cuisses squat_pdc', { poly: true });
  E('presse_cuisses', 'Presse à cuisses', 'squat', 'quadriceps fessiers', 'ischios', 'machines', 'charge', 1,
    ['Dos et bassin plaqués.', 'Descends tant que le bassin reste collé.', 'Pousse sans verrouiller les genoux.'],
    ['Bas du dos qui se décolle.', 'Verrouiller les genoux.'], 'squat_barre goblet', { poly: true, inc: 10 });
  E('squat_pdc', 'Squat au poids du corps', 'squat', 'quadriceps fessiers', '', '', 'reps', 1,
    ['Pieds largeur d’épaules.', 'Descends en 3 secondes, remonte vite.', 'Ajoute une pause en bas pour durcir.'],
    ['Talons décollés.', 'Genoux qui rentrent.'], 'goblet fente_bulgare', { poly: true });
  E('rdl_barre', 'Soulevé de terre roumain barre', 'hanche', 'ischios fessiers', 'dos trapezes avantbras', 'barre', 'charge', 2,
    ['Genoux souples, barre près des jambes.', 'Recule les hanches, dos plat, jusqu’à l’étirement des ischios.', 'Reviens en serrant les fessiers.'],
    ['Dos rond.', 'Barre loin du corps.', 'Descendre au-delà de sa souplesse.'], 'rdl_halteres hip_thrust hip_uni', { poly: true, inc: 5 });
  E('rdl_halteres', 'Soulevé de terre roumain haltères', 'hanche', 'ischios fessiers', 'dos avantbras trapezes', 'halteres', 'charge', 1,
    ['Haltères devant les cuisses.', 'Hanches en arrière, dos neutre.', 'Remonte en poussant les hanches vers l’avant.'],
    ['Transformer en squat.', 'Dos arrondi.'], 'rdl_barre hip_uni', { poly: true, parHaltere: true });
  E('hip_thrust', 'Hip thrust barre', 'hanche', 'fessiers', 'ischios', 'barre+banc', 'charge', 1,
    ['Haut du dos sur le banc, barre protégée sur le bassin.', 'Monte les hanches jusqu’à l’alignement.', 'Serre les fessiers une seconde.'],
    ['Cambrer en haut.', 'Pieds trop loin ou trop près.'], 'rdl_barre hip_uni', { poly: true, inc: 5 });
  E('hip_uni', 'Pont fessier une jambe', 'hanche', 'fessiers ischios', 'abdos', '', 'reps', 1,
    ['Allongé, un pied au sol, l’autre jambe levée.', 'Monte le bassin sans le laisser tourner.', 'Fais les deux côtés.'],
    ['Cambrer.', 'Bassin qui penche.'], 'hip_thrust rdl_halteres', { uni: true });
  E('fente_bulgare', 'Fente bulgare', 'fente', 'quadriceps fessiers', 'ischios abdos', '', 'reps', 2,
    ['Pied arrière sur un support stable.', 'Descends à la verticale, genou avant dans l’axe.', 'Tiens des haltères quand c’est facile.'],
    ['Pied avant trop près.', 'Support instable.'], 'fentes goblet', { poly: true, uni: true, lest: true });
  E('fentes', 'Fentes arrière', 'fente', 'quadriceps fessiers', 'ischios', '', 'reps', 1,
    ['Grand pas vers l’arrière.', 'Descends le genou près du sol.', 'Reviens en poussant sur la jambe avant.'],
    ['Pas trop court.', 'Genou avant qui rentre.'], 'fente_bulgare squat_pdc', { poly: true, uni: true, lest: true });
  E('leg_curl', 'Leg curl à la machine', 'ischios', 'ischios', '', 'machines', 'charge', 1,
    ['Genoux alignés avec l’axe de la machine.', 'Fléchis complètement.', 'Retour lent.'],
    ['Décoller les hanches.', 'Lâcher la charge au retour.'], 'nordic rdl_halteres', { inc: 5 });
  E('nordic', 'Nordic curl (assisté avec les mains)', 'ischios', 'ischios', 'fessiers', '', 'reps', 2,
    ['À genoux sur un coussin, chevilles solidement bloquées.', 'Descends le plus lentement possible, corps droit.', 'Freine avec les mains et repousse pour remonter.'],
    ['Casser aux hanches.', 'Chevilles mal tenues.', 'En faire trop la première fois : courbatures fortes.'], 'leg_curl hip_uni');
  E('mollets', 'Mollets debout', 'mollets', 'mollets', '', '', 'reps', 1,
    ['Avant du pied sur une marche, près d’un appui.', 'Étire en bas, monte le plus haut possible.', 'Une jambe puis l’autre quand c’est facile.'],
    ['Rebondir.', 'Amplitude courte.'], 'mollets_assis', { lest: true });
  E('mollets_assis', 'Mollets assis avec haltères', 'mollets', 'mollets', '', 'halteres', 'charge', 1,
    ['Assis, avant des pieds sur une cale stable, haltères posés sur les genoux.', 'Monte les talons le plus haut possible.', 'Redescends lentement jusqu’à l’étirement.'],
    ['Rebondir.', 'Amplitude courte.'], 'mollets', { parHaltere: true });

  /* Abdominaux */
  E('crunch', 'Crunch', 'abd_flex', 'abdos', '', '', 'reps', 1,
    ['Allongé, genoux pliés.', 'Enroule le haut du dos en soufflant.', 'Redescends lentement.'],
    ['Tirer sur la nuque.', 'Prendre de l’élan.'], 'crunch_poulie roulette releve_sol', { lest: true });
  E('crunch_poulie', 'Crunch à la poulie', 'abd_flex', 'abdos', '', 'poulie', 'charge', 1,
    ['À genoux, corde près de la tête.', 'Enroule la colonne, coudes vers les cuisses.', 'Hanches immobiles.'],
    ['Plier aux hanches seulement.', 'Tirer avec les bras.'], 'crunch roulette', { inc: 2.5 });
  E('releve_suspendu', 'Relevé de genoux suspendu', 'abd_bas', 'abdos', 'avantbras', 'traction|paralleles', 'reps', 2,
    ['Suspendu ou en appui, épaules actives.', 'Monte les genoux en enroulant le bassin.', 'Descends sans balancer.'],
    ['Se balancer.', 'Monter les jambes sans bouger le bassin.'], 'releve_sol roulette', { lest: true, inc: 1 });
  E('releve_sol', 'Relevé de jambes au sol', 'abd_bas', 'abdos', '', '', 'reps', 1,
    ['Bas du dos plaqué.', 'Monte les jambes puis décolle légèrement le bassin.', 'Descends seulement tant que le dos reste au sol ; plie les genoux si besoin.'],
    ['Bas du dos qui se cambre.', 'Chute rapide des jambes.'], 'releve_suspendu dead_bug');
  E('roulette', 'Roulette abdos', 'gainage', 'abdos', 'dos epaules', 'roulette', 'reps', 2,
    ['À genoux, bassin rentré, abdos serrés.', 'Avance aussi loin que le dos reste neutre.', 'Reviens en tirant avec les abdos.'],
    ['Cambrer.', 'Aller trop loin trop tôt.'], 'planche dead_bug');
  E('planche', 'Planche', 'gainage', 'abdos', 'epaules', '', 'temps', 1,
    ['Sur les avant-bras, coudes sous les épaules.', 'Serre fessiers et abdos, corps aligné.', 'Respire régulièrement.'],
    ['Bassin trop haut ou trop bas.', 'Apnée.'], 'dead_bug roulette', { lest: true, inc: 2.5 });
  E('dead_bug', 'Dead bug', 'gainage', 'abdos', '', '', 'reps', 1,
    ['Dos au sol, bras vers le plafond, hanches et genoux à 90°.', 'Allonge bras et jambe opposés en soufflant.', 'Alterne, dos toujours plaqué.'],
    ['Bas du dos qui décolle.', 'Aller vite.'], 'planche releve_sol', { uni: true });
  E('planche_lat', 'Planche latérale', 'obliques', 'abdos', 'epaules', '', 'temps', 1,
    ['Coude sous l’épaule, corps aligné.', 'Monte la hanche et tiens.', 'Fais le même temps de chaque côté.'],
    ['Hanche qui s’affaisse.', 'Buste qui tourne.'], 'pallof woodchop suitcase', { uni: true, lest: true, inc: 2.5 });
  E('pallof', 'Pallof press', 'obliques', 'abdos', '', 'poulie|elastiques', 'reps', 1,
    ['De profil à la poulie ou à l’élastique, mains au sternum.', 'Tends les bras sans laisser le buste tourner.', 'Tiens 2 secondes, fais les deux côtés.'],
    ['Pivoter.', 'Résistance trop forte.'], 'planche_lat woodchop', { uni: true, lest: true, inc: 2.5 });
  E('woodchop', 'Rotation à la poulie (woodchop)', 'obliques', 'abdos', 'epaules', 'poulie', 'charge', 2,
    ['De profil, bras presque tendus.', 'Tourne le buste et les hanches en diagonale.', 'Retour lent, deux côtés.'],
    ['Tirer avec les bras.', 'Tordre le bas du dos avec des charges lourdes.'], 'pallof planche_lat', { uni: true, inc: 2.5 });
  E('suitcase', 'Marche valise (un haltère)', 'obliques', 'abdos', 'avantbras trapezes', 'halteres', 'temps', 1,
    ['Un seul haltère lourd d’un côté.', 'Marche droit sans te pencher.', 'Même durée de l’autre côté.'],
    ['Se pencher pour compenser.', 'Dos rond en ramassant.'], 'planche_lat pallof', { uni: true, lest: true });

  FM.EXERCICES = list;
  FM.EX = Object.assign(Object.create(null), Object.fromEntries(list.map(e => [e.id, e])));

  FM.faisable = (ex, materiel) => ex.equip.some(g => g.every(m => materiel.includes(m)));
  /* Alternatives : liste de l'exercice, puis exercices du même mouvement. */
  FM.alternatives = function (id, materiel) {
    const ex = FM.EX[id];
    if (!ex) return [];
    const ids = [...ex.alternatives, ...list.filter(e => e.pattern === ex.pattern).map(e => e.id)];
    return [...new Set(ids)].filter(i => i !== id && FM.EX[i] && (!materiel || FM.faisable(FM.EX[i], materiel)));
  };

  FM.SPORTS = ['Course à pied', 'Marche', 'Randonnée', 'Vélo', 'Vélo d’appartement', 'Rameur', 'Elliptique', 'Natation',
    'Corde à sauter', 'HIIT', 'Boxe / arts martiaux', 'Football', 'Basket', 'Tennis / raquettes', 'Escalade', 'Autre'];
})(typeof window !== 'undefined' ? window : globalThis);
