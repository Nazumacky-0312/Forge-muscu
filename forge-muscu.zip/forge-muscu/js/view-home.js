/* Accueil : séance du jour. */
(function (root) {
  'use strict';
  const FM = root.FM, h = FM.h;
  FM.vues = FM.vues || {};

  /* Prochaine séance : celle qui suit la dernière faite dans le programme. */
  FM.prochainJour = function (etat) {
    const jours = etat.programme.jours.filter(j => j.items.length);
    if (!jours.length) return null;
    const ordre = [...etat.seances].sort((a, b) => b.debut - a.debut);
    for (const s of ordre) {
      const i = jours.findIndex(j => j.id === s.jourId);
      if (i >= 0) return jours[(i + 1) % jours.length];
    }
    return jours[0];
  };

  FM.apercu = jour => h('ul', { class: 'apercu' }, jour.items.map(it => h('li', {},
    FM.lien('#/exercice/' + it.exId, FM.EX[it.exId].nom), h('small', {}, FM.resumeItem(it)))));

  FM.vues.accueil = function (app) {
    const e = app.etat, p = e.profil, maintenant = new Date();
    const vue = h('div', {}, h('p', { class: 'surtitre' }, FM.dateLongue(maintenant)), h('h1', {}, p.prenom ? `Salut ${p.prenom}` : 'Prêt à t’entraîner ?'));
    const debutSemaine = FM.lundi(maintenant).getTime();
    const faites = e.seances.filter(s => s.debut >= debutSemaine);
    const cardioSem = e.cardio.filter(c => c.date >= debutSemaine).reduce((t, c) => t + c.duree, 0);

    vue.append(h('div', { class: 'tuiles' },
      h('div', { class: 'tuile' }, h('strong', {}, `${faites.length} / ${p.jours}`), h('span', {}, 'séances cette semaine')),
      h('div', { class: 'tuile' }, h('strong', {}, `${cardioSem} min`), h('span', {}, 'cardio et sports'))));

    const prochain = FM.prochainJour(e);
    const aujourdhui = faites.filter(s => FM.cleJour(s.debut) === FM.cleJour(maintenant));
    const prevu = p.joursSemaine.includes(maintenant.getDay());

    if (e.active) {
      const n = e.active.exercices.reduce((t, x) => t + x.series.filter(s => s.fait).length, 0);
      vue.append(FM.carte(h('p', { class: 'surtitre' }, 'Séance en cours'), h('h2', {}, e.active.nom), h('p', {}, `${n} série(s) validée(s), commencée à ${new Date(e.active.debut).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}.`),
        FM.btn('Reprendre la séance', () => app.aller('#/seance'), 'primaire geant')));
    } else if (!prochain) {
      vue.append(FM.carte(h('h2', {}, 'Programme vide'), h('p', {}, 'Ajoute des exercices ou régénère le programme.'), FM.btn('Ouvrir le programme', () => app.aller('#/programme'), 'primaire geant')));
    } else {
      let choisi = prochain;
      const zone = h('div');
      const dessiner = () => zone.replaceChildren(h('h2', {}, choisi.nom), h('p', { class: 'discret' }, `Environ ${FM.duree(choisi.items)} min, échauffement compris`), FM.apercu(choisi));
      dessiner();
      let titre = 'Séance du jour', message = null, bouton = 'Commencer la séance', classe = 'primaire geant';
      if (aujourdhui.length) { titre = 'Prochaine séance'; message = 'Séance du jour terminée, bravo. Place à la récupération.'; bouton = 'Faire une autre séance'; classe = 'geant'; }
      else if (!prevu) {
        titre = 'Jour de repos'; bouton = 'S’entraîner quand même'; classe = 'geant';
        let k = 1; while (k < 7 && !p.joursSemaine.includes((maintenant.getDay() + k) % 7)) k++;
        const d = new Date(maintenant); d.setDate(d.getDate() + k);
        message = `Prochaine séance prévue ${FM.dateLongue(d)}. Marche, cardio léger et sommeil aident à récupérer.`;
      }
      const select = e.programme.jours.filter(j => j.items.length).length > 1 ? FM.champ('Changer de séance', h('select', {
        value: choisi.id, onchange: ev => { choisi = e.programme.jours.find(j => j.id === ev.target.value); dessiner(); }
      }, e.programme.jours.filter(j => j.items.length).map(j => h('option', { value: j.id }, j.nom)))) : null;
      vue.append(FM.carte(h('p', { class: 'surtitre' }, titre), message ? h('p', {}, message) : null, zone,
        FM.btn(bouton, () => app.demarrerSeance(choisi), classe), select));
      if (!prevu || aujourdhui.length) vue.append(FM.btn('Noter du cardio ou un sport', () => app.aller('#/cardio'), 'geant'));
    }

    if (e.seances.length >= 3 && Date.now() - (e.dernierExport || 0) > 30 * 864e5) {
      vue.append(FM.carte(h('h3', {}, 'Pense à sauvegarder'), h('p', {}, 'Tes données sont uniquement sur cet appareil. Exporte une copie de temps en temps.'), FM.btn('Exporter mes données', () => { app.exporter(); app.rendre(); })));
    }
    vue.append(h('p', { class: 'alerte' }, 'Douleur vive, douleur dans la poitrine, malaise ou essoufflement anormal : arrête immédiatement. Urgence : 15 ou 112.'));
    return vue;
  };
})(typeof window !== 'undefined' ? window : globalThis);
