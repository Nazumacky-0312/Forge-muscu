/*
 * Minuteur de repos. Le temps restant vient d'une heure de fin (exact même après une mise en veille).
 * Mode « écran éteint » : un fichier son généré sur place (quasi-silence puis bips) est lu comme un
 * média, ce que le navigateur continue de jouer écran verrouillé.
 */
(function (root) {
  'use strict';
  const FM = root.FM || (root.FM = {});
  const HZ = 8000;

  FM.creerWav = function (attente) {
    const bips = [[0, 880], [0.45, 880], [0.9, 1320]];
    const n = Math.round((attente + 1.6) * HZ);
    const buf = new ArrayBuffer(44 + n);
    const v = new DataView(buf);
    const txt = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    txt(0, 'RIFF'); v.setUint32(4, 36 + n, true); txt(8, 'WAVEfmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, HZ, true); v.setUint32(28, HZ, true); v.setUint16(32, 1, true); v.setUint16(34, 8, true);
    txt(36, 'data'); v.setUint32(40, n, true);
    const data = new Uint8Array(buf, 44);
    /* Variation infime (inaudible) pour que le flux ne soit pas traité comme vide. */
    for (let i = 0; i < n; i++) data[i] = 128 + ((i >> 6) & 1);
    for (const [debut, f] of bips) {
      const a = Math.round((attente + debut) * HZ), len = Math.round(0.3 * HZ);
      for (let i = 0; i < len && a + i < n; i++) {
        const env = Math.min(1, i / 80, (len - i) / 80);
        data[a + i] = 128 + Math.round(Math.sin(2 * Math.PI * f * i / HZ) * 115 * env);
      }
    }
    return buf;
  };

  const timer = FM.timer = { app: null, audio: null, url: null, ctx: null, oscillos: [], mode: 'aucun', attente: 0 };
  const etat = () => timer.app.etat;

  timer.init = function (app) {
    this.app = app;
    setInterval(() => this.verifier(), 250);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) { this.resynchroniser(); this.verifier(); } });
  };

  timer.restant = () => (etat().repos ? (etat().repos.fin - Date.now()) / 1000 : 0);

  function contexte() {
    const C = root.AudioContext || root.webkitAudioContext;
    if (!C) return null;
    if (!timer.ctx) timer.ctx = new C();
    if (timer.ctx.state === 'suspended') timer.ctx.resume().catch(() => {});
    return timer.ctx;
  }

  timer.bip = function (dans) {
    const c = contexte();
    if (!c) return;
    [[0, 880], [0.45, 880], [0.9, 1320]].forEach(([d, f]) => {
      const o = c.createOscillator(), g = c.createGain(), t = c.currentTime + (dans || 0) + d;
      o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.6, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
      o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + 0.32);
      this.oscillos.push(o);
    });
  };

  timer.couperSon = function () {
    this.oscillos.forEach(o => { try { o.stop(); } catch (e) { /* déjà arrêté */ } });
    this.oscillos = [];
    if (this.audio) { this.audio.pause(); this.audio.removeAttribute('src'); this.audio.load(); }
    if (this.url) { URL.revokeObjectURL(this.url); this.url = null; }
    this.mode = 'aucun';
  };

  /* À appeler depuis un appui de l'utilisateur (règle des navigateurs pour le son). */
  timer.armer = function () {
    this.couperSon();
    const r = etat().repos, reg = etat().reglages, s = this.restant();
    if (!r || s <= 0 || !reg.son) return;
    if (reg.ecranEteint) {
      if (!this.audio) {
        this.audio = new Audio();
        this.audio.addEventListener('timeupdate', () => this.verifier());
        this.audio.addEventListener('ended', () => { this.verifier(); this.couperSon(); });
      }
      this.attente = s;
      this.url = URL.createObjectURL(new Blob([FM.creerWav(s)], { type: 'audio/wav' }));
      this.audio.src = this.url;
      this.mode = 'media';
      this.audio.play().then(() => {
        if ('mediaSession' in navigator && root.MediaMetadata) navigator.mediaSession.metadata = new root.MediaMetadata({ title: 'Repos en cours', artist: r.libelle || 'Forge Muscu', album: 'Forge Muscu' });
      }).catch(err => {
        if (err && err.name === 'AbortError') return; // remplacé par un nouveau repos
        this.mode = 'bloque';
        this.app.rafraichirRepos();
      });
    } else {
      this.mode = 'simple';
      this.bip(s);
    }
  };

  timer.resynchroniser = function () {
    const s = this.restant();
    if (this.mode !== 'media' || !this.audio || s <= 0.5) return;
    const voulu = Math.max(0, this.attente - s);
    if (this.audio.paused || Math.abs(this.audio.currentTime - voulu) > 1.5) {
      this.audio.currentTime = voulu;
      this.audio.play().catch(() => { this.mode = 'bloque'; });
    }
  };

  timer.demarrer = function (secondes, libelle) {
    if (secondes <= 0) return this.arreter();
    etat().repos = { fin: Date.now() + secondes * 1000, total: secondes, libelle: libelle || '', signale: false };
    this.armer();
    this.app.sauver(); this.app.rafraichirRepos();
  };

  timer.ajuster = function (delta) {
    const r = etat().repos;
    if (!r) return;
    const s = Math.min(900, Math.max(0, Math.max(0, this.restant()) + delta));
    if (s <= 0) return this.arreter();
    r.fin = Date.now() + s * 1000; r.total = Math.max(r.total + delta, s); r.signale = false;
    this.armer();
    this.app.sauver(); this.app.rafraichirRepos();
  };

  timer.arreter = function () {
    this.couperSon();
    etat().repos = null;
    this.app.sauver(); this.app.rafraichirRepos();
  };

  timer.verifier = function () {
    const r = this.app && etat().repos;
    if (!r) return;
    const retard = Date.now() - r.fin;
    if (retard >= 0 && !r.signale) {
      r.signale = true;
      this.app.sauver();
      if (retard < 4000) this.signaler(r);
    }
    this.app.rafraichirRepos();
  };

  timer.signaler = function (r) {
    const reg = etat().reglages;
    /* En mode média ou simple, les bips sont déjà programmés. Sinon on les joue maintenant. */
    const dejaProgramme = (this.mode === 'media' && this.audio && !this.audio.paused) || (this.mode === 'simple' && this.ctx && this.ctx.state === 'running');
    if (reg.son && !dejaProgramme) this.bip(0);
    if (reg.vibration && navigator.vibrate) { try { navigator.vibrate([400, 150, 400, 150, 600]); } catch (e) { /* non pris en charge */ } }
    if (reg.notifications && document.hidden) this.notifier('Repos terminé 💪', r.libelle || 'Série suivante !');
  };

  timer.notifier = function (titre, corps) {
    if (!('Notification' in root) || root.Notification.permission !== 'granted' || !navigator.serviceWorker) return;
    navigator.serviceWorker.ready.then(reg => reg.showNotification(titre, { body: corps, tag: 'repos', renotify: true, icon: 'icons/icon-192.png', vibrate: [400, 150, 400] })).catch(() => {});
  };

  /* Écran maintenu allumé pendant la séance. */
  let verrou = null, demande = false;
  FM.ecran = async function (voulu) {
    if (!navigator.wakeLock) return;
    try {
      if (voulu && !verrou && !demande && !document.hidden) {
        demande = true;
        verrou = await navigator.wakeLock.request('screen');
        verrou.addEventListener('release', () => { verrou = null; });
      } else if (!voulu && verrou) { await verrou.release(); verrou = null; }
    } catch (e) { /* refusé (batterie faible, etc.) */ } finally { demande = false; }
  };
})(typeof window !== 'undefined' ? window : globalThis);
