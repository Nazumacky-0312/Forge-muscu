/* Génération du programme full body. */
(function (root) {
  'use strict';
  const FM = root.FM || (root.FM = {});
  const JAMBES = ['quadriceps', 'ischios', 'fessiers', 'mollets'];

  FM.joursParDefaut = n => (n === 4 ? [1, 2, 4, 5] : [1, 3, 5]); // 0 = dimanche

  /* [mouvements par ordre de préférence, importance, exercices préférés, obligatoire] */
  const S = (p, imp, pref, oblig) => ({ p: p.split(' '), imp, pref: pref ? pref.split(' ') : [], oblig: !!oblig });
  const MODELES = {
    A: [S('squat', 8, 'squat_barre goblet'), S('pouss_h', 9, 'dc_barre dc_halteres'), S('tir_v tir_h', 8, 'tirage_vertical tractions'),
      S('elev_lat arriere', 6, 'lat_halteres'), S('marteau', 6, 'curl_marteau', true), S('abd_flex gainage', 7, 'crunch_poulie crunch', true),
      S('avb_flex', 1, 'curl_poignets'), S('ischios', 3, 'leg_curl'), S('triceps', 2, 'triceps_poulie')],
    B: [S('hanche', 8, 'rdl_barre rdl_halteres'), S('pouss_inc pouss_h', 9, 'di_halteres'), S('tir_h', 8, 'rowing_poulie rowing_haltere'),
      S('shrug arriere', 6, 'shrug_halteres'), S('obliques', 7, 'pallof planche_lat', true), S('portage avb_flex', 5, 'farmer suspension'),
      S('mollets', 2, 'mollets'), S('triceps', 2, 'triceps_nuque')],
    C: [S('fente squat', 8, 'fente_bulgare fentes'), S('pouss_v', 9, 'de_halteres'), S('ecarte dips pouss_h', 7, 'ecarte_poulie pec_deck dips'),
      S('tir_v tir_h', 8, 'tractions rowing_haltere'), S('marteau', 6, 'marteau_poulie curl_marteau', true), S('abd_bas gainage', 7, 'releve_suspendu releve_sol', true),
      S('arriere', 4, 'face_pull oiseau'), S('avb_ext', 1, 'ext_poignets curl_inverse'), S('squat', 3.5, 'presse_cuisses goblet')],
    D: [S('dips pouss_h', 9, 'dips presse_pecs pompes'), S('ischios hanche', 8, 'leg_curl nordic'), S('tir_h', 8, 'rowing_haltere rowing_barre'),
      S('elev_lat', 5, 'lat_poulie lat_halteres'), S('shrug arriere', 6, 'shrug_barre shrug_halteres'), S('gainage', 7, 'roulette planche', true),
      S('avb_ext avb_flex', 4, 'curl_inverse'), S('squat', 8.5, 'presse_cuisses goblet')]
  };

  FM.prescription = function (ex, profil) {
    const o = profil.objectif;
    let r;
    if (ex.mode === 'temps') r = { series: 3, min: 20, max: 45, repos: 60 };
    else if (ex.poly) {
      r = o === 'force' ? { series: 4, min: 4, max: 6, repos: 180 }
        : o === 'seche' ? { series: 3, min: 8, max: 12, repos: 90 }
          : { series: 3, min: 6, max: 10, repos: 120 };
      if (ex.mode === 'reps') Object.assign(r, { min: Math.max(r.min, 6), max: Math.max(r.max + 5, 15) });
    } else {
      r = o === 'force' ? { series: 3, min: 8, max: 12, repos: 90 }
        : o === 'seche' ? { series: 3, min: 12, max: 20, repos: 45 }
          : { series: 3, min: 10, max: 15, repos: 75 };
    }
    if (profil.niveau === 'debutant') r.series = Math.max(2, r.series - 1);
    return r;
  };

  FM.item = (exId, profil) => Object.assign({ exId }, FM.prescription(FM.EX[exId], profil));

  /* Durée estimée en minutes, échauffement compris. */
  FM.duree = function (items) {
    let s = 6 * 60;
    for (const it of items) {
      const ex = FM.EX[it.exId];
      if (!ex) continue;
      const travail = (ex.mode === 'temps' ? it.max : 35) * (ex.uni ? 2 : 1);
      s += it.series * travail + Math.max(0, it.series - 1) * it.repos + 60;
    }
    return Math.round(s / 60);
  };

  const estPrioritaire = (ex, prio) => ex.muscles.some(m => prio.includes(m) || (prio.includes('jambes') && JAMBES.includes(m)));
  const estJambesOuDos = ex => ex.muscles.some(m => m === 'dos' || JAMBES.includes(m));

  function choisir(slot, profil, dansJour, usage) {
    const mat = profil.materiel;
    const maxNiv = profil.niveau === 'debutant' ? 1 : 2;
    for (const strict of [true, false]) {
      for (const pat of slot.p) {
        const c = FM.EXERCICES.filter(e => e.pattern === pat && FM.faisable(e, mat) && !dansJour.has(e.id) && (!strict || e.niveau <= maxNiv));
        if (!c.length) continue;
        const score = e => {
          const i = slot.pref.indexOf(e.id);
          let s = i >= 0 ? 100 - i * 5 : 0;
          s -= (usage[e.id] || 0) * (e.pattern === 'marteau' ? 1 : 40); // variété sur la semaine
          if (e.equip[0].length) s += 20; // avec matériel : charge plus facile à faire progresser
          if (e.mode === 'temps' && e.pattern === 'tir_h') s -= 30;
          return s;
        };
        c.sort((a, b) => score(b) - score(a));
        return c[0];
      }
    }
    return null;
  }

  FM.genererProgramme = function (profil) {
    const lettres = profil.jours === 4 ? ['A', 'B', 'C', 'D'] : ['A', 'B', 'C'];
    const usage = {};
    const manques = new Set();
    const jours = lettres.map(L => {
      const pris = new Set();
      let choix = [];
      for (const slot of MODELES[L]) {
        const ex = choisir(slot, profil, pris, usage);
        if (!ex) { if (slot.imp >= 5) manques.add(slot.p[0]); continue; }
        pris.add(ex.id);
        const it = FM.item(ex.id, profil);
        const prio = estPrioritaire(ex, profil.priorites);
        choix.push({ it, ex, slot, score: slot.imp + (prio ? 2.5 : 0), prio });
      }
      /* Ajuste au temps disponible : d'abord les séries, puis les exercices les moins importants. */
      const cible = profil.duree;
      const total = () => FM.duree(choix.map(c => c.it));
      const retirable = () => choix.filter(c => !c.slot.oblig && !(estJambesOuDos(c.ex) && choix.filter(x => estJambesOuDos(x.ex)).length <= 2))
        .sort((a, b) => a.score - b.score)[0];
      while (total() > cible + 1) {
        const faible = retirable();
        if (faible && (choix.length > 6 || (cible <= 30 && choix.length > 5))) { choix = choix.filter(c => c !== faible); continue; }
        const reductible = choix.filter(c => c.it.series > 2).sort((a, b) => a.score - b.score)[0];
        if (reductible) { reductible.it.series--; continue; }
        if (faible && choix.length > 4) { choix = choix.filter(c => c !== faible); continue; }
        const longRepos = choix.filter(c => c.it.repos > 60).sort((a, b) => b.it.repos - a.it.repos)[0];
        if (longRepos) { longRepos.it.repos -= 15; continue; }
        break;
      }
      /* Temps restant : une série de plus, d'abord sur les mouvements polyarticulaires (priorités, jambes, dos). */
      const rang = c => (c.ex.poly ? 100 : 0) + c.score;
      for (const c of [...choix].sort((a, b) => rang(b) - rang(a))) {
        if ((c.prio || (c.ex.poly && estJambesOuDos(c.ex))) && c.it.series < 4 && profil.niveau !== 'debutant') {
          c.it.series++;
          if (total() > cible + 2) c.it.series--;
        }
      }
      choix.forEach(c => { usage[c.ex.id] = (usage[c.ex.id] || 0) + 1; });
      return { id: 'j' + L, nom: 'Full body ' + L, items: choix.map(c => c.it) };
    });
    if (!jours.some(j => j.items.some(i => FM.EX[i.exId].muscles.includes('dos') && FM.EX[i.exId].mode !== 'temps' && FM.EX[i.exId].pattern !== 'arriere'))) manques.add('dos');
    return { creeLe: new Date().toISOString(), jours, manques: [...manques] };
  };

  /* Séries hebdomadaires par muscle (principal = 1, secondaire = 0,5). */
  FM.volumeHebdo = function (programme, joursParSemaine) {
    const v = Object.fromEntries(Object.keys(FM.MUSCLES).map(m => [m, 0]));
    const n = programme.jours.length;
    if (!n) return v;
    const facteur = joursParSemaine / n;
    for (const j of programme.jours) for (const it of j.items) {
      const ex = FM.EX[it.exId];
      if (!ex) continue;
      ex.muscles.forEach(m => { v[m] += it.series * facteur; });
      ex.secondaires.forEach(m => { v[m] += it.series * 0.5 * facteur; });
    }
    for (const m in v) v[m] = Math.round(v[m] * 2) / 2;
    return v;
  };

  FM.NOMS_MOUVEMENTS = {
    squat: 'squat', pouss_h: 'développé', pouss_inc: 'développé incliné', pouss_v: 'poussée épaules', tir_v: 'tirage vertical', tir_h: 'rowing',
    elev_lat: 'élévations latérales', marteau: 'curl marteau', abd_flex: 'abdominaux', abd_bas: 'abdominaux', gainage: 'gainage',
    hanche: 'chaîne postérieure', shrug: 'trapèzes', portage: 'prise / avant-bras', obliques: 'obliques', fente: 'fentes',
    ecarte: 'isolation pectoraux', dips: 'dips', ischios: 'ischio-jambiers', dos: 'dos (ajoute une barre de traction, des élastiques ou des haltères)', avb_ext: 'avant-bras', avb_flex: 'avant-bras', arriere: 'arrière d’épaule'
  };
})(typeof window !== 'undefined' ? window : globalThis);
