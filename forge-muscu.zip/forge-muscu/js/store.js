/* Sauvegarde locale, export et import. */
(function (root) {
  'use strict';
  const FM = root.FM || (root.FM = {});
  const CLE = 'forge-muscu:v1';

  FM.profilDefaut = () => ({
    prenom: '', objectif: 'muscle', niveau: 'intermediaire', jours: 3, joursSemaine: [1, 3, 5], duree: 45,
    materiel: [...FM.PRESETS.salle.materiel],
    priorites: ['pectoraux', 'epaules', 'avantbras', 'trapezes', 'abdos']
  });
  FM.reglagesDefaut = () => ({ son: true, ecranEteint: true, vibration: true, notifications: false, ecranAllume: true });

  FM.etatInitial = function () {
    const profil = FM.profilDefaut();
    return { version: 1, profil, reglages: FM.reglagesDefaut(), programme: FM.genererProgramme(profil), seances: [], cardio: [], cibles: {}, active: null, repos: null, dernierExport: null };
  };

  const objet = v => v && typeof v === 'object' && !Array.isArray(v);
  const nombre = (v, def, min, max) => { const n = Number(v); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def; };
  const texte = (v, max) => (typeof v === 'string' ? v.slice(0, max || 500) : '');
  const parmi = (v, liste, def) => (liste.includes(v) ? v : def);
  const ident = v => (typeof v === 'string' && /^[\w-]{1,60}$/.test(v) ? v : FM.uid());
  const tableau = v => (Array.isArray(v) ? v : []);

  FM.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  function nettoyerItem(i) {
    if (!objet(i) || !FM.EX[i.exId]) return null;
    const min = nombre(i.min, 8, 1, 600);
    return { exId: i.exId, series: Math.round(nombre(i.series, 3, 1, 12)), min, max: nombre(i.max, 12, min, 600), repos: Math.round(nombre(i.repos, 90, 0, 600)) };
  }
  function nettoyerSeance(s) {
    if (!objet(s) || !Number.isFinite(Number(s.debut))) return null;
    return {
      id: ident(s.id), jourId: texte(s.jourId, 60), nom: texte(s.nom, 80) || 'Séance', debut: Number(s.debut), fin: nombre(s.fin, Number(s.debut), 0, 1e14),
      note: texte(s.note, 1000), echauffement: !!s.echauffement, index: Math.round(nombre(s.index, 0, 0, 100)),
      exercices: tableau(s.exercices).filter(e => objet(e) && FM.EX[e.exId]).map(e => ({
        exId: e.exId, prevu: nettoyerItem(Object.assign({ exId: e.exId }, e.prevu)),
        ressenti: parmi(e.ressenti, ['facile', 'correct', 'difficile', 'echec'], null), douleur: !!e.douleur,
        series: tableau(e.series).filter(objet).map(x => ({ kg: nombre(x.kg, 0, 0, 1000), reps: Math.round(nombre(x.reps, 0, 0, 3600)), fait: !!x.fait }))
      }))
    };
  }

  /* Valide et complète des données (chargement ou import). Lève une erreur si le format est inconnu. */
  FM.normaliser = function (d) {
    if (!objet(d) || d.version !== 1 || !objet(d.profil) || !Array.isArray(d.seances)) throw new Error('Ce fichier n’est pas une sauvegarde Forge Muscu compatible.');
    const def = FM.profilDefaut();
    const p = d.profil;
    const jours = p.jours === 4 ? 4 : 3;
    let js = [...new Set(tableau(p.joursSemaine).map(Number).filter(n => Number.isInteger(n) && n >= 0 && n <= 6))].sort();
    if (js.length !== jours) js = FM.joursParDefaut(jours);
    const profil = {
      prenom: texte(p.prenom, 40), objectif: parmi(p.objectif, ['muscle', 'force', 'seche'], def.objectif),
      niveau: parmi(p.niveau, ['debutant', 'intermediaire', 'avance'], def.niveau), jours, joursSemaine: js,
      duree: parmi(Number(p.duree), [30, 45, 60], 45),
      materiel: Array.isArray(p.materiel) ? p.materiel.filter(m => FM.MATERIEL[m]) : def.materiel,
      priorites: Array.isArray(p.priorites) ? p.priorites.filter(m => FM.PRIORITES[m]) : def.priorites
    };
    const reglages = FM.reglagesDefaut();
    for (const k in reglages) if (objet(d.reglages) && typeof d.reglages[k] === 'boolean') reglages[k] = d.reglages[k];
    let programme;
    if (objet(d.programme) && Array.isArray(d.programme.jours)) {
      programme = {
        creeLe: texte(d.programme.creeLe, 40), manques: tableau(d.programme.manques).filter(m => FM.NOMS_MOUVEMENTS[m]),
        jours: d.programme.jours.filter(objet).map(j => ({ id: ident(j.id), nom: texte(j.nom, 60) || 'Séance', items: tableau(j.items).map(nettoyerItem).filter(Boolean) }))
      };
    } else programme = FM.genererProgramme(profil);
    const cibles = {};
    if (objet(d.cibles)) for (const k in d.cibles) {
      const c = d.cibles[k];
      if (FM.EX[k] && objet(c)) cibles[k] = { kg: nombre(c.kg, 0, 0, 1000), reps: Math.round(nombre(c.reps, 8, 1, 3600)), depuis: nombre(c.depuis, 0, 0, 1e14) };
    }
    const active = d.active ? nettoyerSeance(d.active) : null;
    let repos = null;
    if (active && objet(d.repos) && Number.isFinite(d.repos.fin)) repos = { fin: d.repos.fin, total: nombre(d.repos.total, 90, 1, 900), libelle: texte(d.repos.libelle, 100), signale: !!d.repos.signale };
    return {
      version: 1, profil, reglages, programme, cibles, active, repos,
      seances: d.seances.map(nettoyerSeance).filter(Boolean),
      cardio: tableau(d.cardio).filter(c => objet(c) && Number.isFinite(Number(c.date))).map(c => ({
        id: ident(c.id), date: Number(c.date), sport: texte(c.sport, 60) || 'Autre', duree: Math.round(nombre(c.duree, 1, 1, 1440)),
        intensite: Math.round(nombre(c.intensite, 5, 1, 10)), distance: nombre(c.distance, 0, 0, 2000), note: texte(c.note, 500)
      })),
      dernierExport: Number.isFinite(d.dernierExport) ? d.dernierExport : null
    };
  };

  FM.store = {
    erreur: null,
    avertir: null,
    charger() {
      let brut = null;
      try { brut = root.localStorage.getItem(CLE); } catch (e) { this.erreur = 'Le stockage local est bloqué (navigation privée ?). Tes données ne seront pas conservées.'; }
      if (brut) {
        try { return FM.normaliser(JSON.parse(brut)); } catch (e) {
          try { root.localStorage.setItem(CLE + ':secours-' + Date.now(), brut); } catch (_) { /* rien à faire */ }
          this.erreur = 'La sauvegarde était illisible. Une copie de secours a été gardée sur cet appareil.';
        }
      }
      return FM.etatInitial();
    },
    sauver(etat) {
      try { root.localStorage.setItem(CLE, JSON.stringify(etat)); return true; } catch (e) {
        if (this.avertir) this.avertir('Sauvegarde impossible : stockage plein ou bloqué. Exporte tes données.');
        return false;
      }
    },
    exporter(etat) { return JSON.stringify(Object.assign({ application: 'forge-muscu', exporteLe: new Date().toISOString() }, etat, { repos: null }), null, 1); },
    importer(texteJson) {
      let d;
      try { d = JSON.parse(texteJson); } catch (e) { throw new Error('Fichier JSON illisible.'); }
      return FM.normaliser(d);
    },
    CLE
  };
})(typeof window !== 'undefined' ? window : globalThis);
