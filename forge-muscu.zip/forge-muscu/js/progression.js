/* Records, historique par exercice et propositions de progression. */
(function (root) {
  'use strict';
  const FM = root.FM || (root.FM = {});

  FM.arrondir = (v, pas) => Math.round(Math.round(v / pas) * pas * 100) / 100;
  /* 1RM estimé (Epley), seulement jusqu'à 12 répétitions. */
  FM.e1rm = (kg, reps) => (kg > 0 && reps >= 1 && reps <= 12 ? Math.round((reps === 1 ? kg : kg * (1 + reps / 30)) * 10) / 10 : 0);

  const faites = entree => entree.series.filter(s => s.fait && s.reps > 0);

  /* Passages d'un exercice, du plus ancien au plus récent. */
  FM.historiqueExercice = function (seances, exId) {
    const out = [];
    for (const s of [...seances].sort((a, b) => a.debut - b.debut)) {
      for (const e of s.exercices) {
        if (e.exId !== exId) continue;
        const series = faites(e);
        if (series.length) out.push({ seanceId: s.id, date: s.debut, series, entree: e });
      }
    }
    return out;
  };

  FM.stats = function (series) {
    return {
      kg: Math.max(0, ...series.map(s => s.kg || 0)),
      reps: Math.max(0, ...series.map(s => s.reps || 0)),
      e1rm: Math.max(0, ...series.map(s => FM.e1rm(s.kg || 0, s.reps || 0))),
      volume: Math.round(series.reduce((t, s) => t + (s.kg || 0) * (s.reps || 0), 0)),
      total: series.reduce((t, s) => t + (s.reps || 0), 0)
    };
  };

  /* Indicateurs suivis selon le type d'exercice. */
  FM.indicateurs = function (ex, hist) {
    const charge = hist.some(h => h.series.some(s => s.kg > 0));
    if (ex.mode === 'temps') return [['reps', 'Meilleur temps', 's'], ...(charge ? [['kg', 'Charge max', 'kg']] : []), ['total', 'Temps total par séance', 's']];
    if (ex.mode === 'reps' && !charge) return [['reps', 'Répétitions max', 'rép.'], ['total', 'Répétitions par séance', 'rép.']];
    return [['kg', 'Charge max', 'kg'], ['e1rm', '1RM estimé', 'kg'], ['volume', 'Volume par séance', 'kg'], ['reps', 'Répétitions max', 'rép.']];
  };

  FM.records = function (seances, exId) {
    const ex = FM.EX[exId];
    const hist = FM.historiqueExercice(seances, exId);
    if (!ex || !hist.length) return [];
    return FM.indicateurs(ex, hist).map(([cle, nom, unite]) => {
      let best = 0, date = null;
      for (const h of hist) { const v = FM.stats(h.series)[cle]; if (v > best) { best = v; date = h.date; } }
      return { cle, nom, unite, valeur: best, date };
    }).filter(r => r.valeur > 0);
  };

  /* Records battus par une séance par rapport aux précédentes (pas au premier passage). */
  FM.nouveauxRecords = function (seances, seance) {
    const avant = seances.filter(s => s.id !== seance.id && s.debut < seance.debut);
    const out = [];
    for (const exId of new Set(seance.exercices.map(e => e.exId))) {
      const anciens = Object.fromEntries(FM.records(avant, exId).map(r => [r.cle, r.valeur]));
      if (!Object.keys(anciens).length) continue;
      for (const r of FM.records([seance], exId)) if (r.valeur > (anciens[r.cle] || 0)) out.push(Object.assign({ exId, avant: anciens[r.cle] || 0 }, r));
    }
    return out;
  };

  /*
   * Double progression : d'abord les répétitions, puis la charge.
   * Renvoie { type, titre, raison, cible: {kg, reps} } ou null sans historique.
   */
  FM.proposer = function (seances, exId, item) {
    const ex = FM.EX[exId];
    const hist = FM.historiqueExercice(seances, exId);
    if (!ex) return null;
    /* Une douleur signalée au dernier passage prime, même sans série validée. */
    const dernierPassage = [...seances].sort((a, b) => b.debut - a.debut).map(s => ({ s, e: s.exercices.filter(e => e.exId === exId) })).find(x => x.e.length);
    if (dernierPassage && dernierPassage.e.some(e => e.douleur)) {
      const avant = hist.length ? Math.max(0, ...hist[hist.length - 1].series.map(s => s.kg || 0)) : 0;
      return { type: 'douleur', titre: 'Douleur signalée : ne force pas', raison: 'N’augmente rien. Choisis une alternative ou reprends plus léger seulement si la douleur a disparu. Si elle persiste, consulte un professionnel de santé.',
        cible: { kg: avant ? FM.arrondir(avant * 0.8, ex.inc) : 0, reps: item.min }, date: dernierPassage.s.debut };
    }
    if (!hist.length) return null;
    const d = hist[hist.length - 1];
    const series = d.series;
    const kg = Math.max(0, ...series.map(s => s.kg || 0));
    /* Les séries à la charge de travail servent de référence. */
    const travail = series.filter(s => (s.kg || 0) >= kg * 0.95);
    const minReps = Math.min(...travail.map(s => s.reps));
    const prevues = d.entree.prevu ? d.entree.prevu.series : item.series;
    const complet = series.length >= prevues;
    const ressenti = d.entree.ressenti || 'correct';
    const u = ex.mode === 'temps' ? 's' : 'rép.';
    const pas = ex.mode === 'temps' ? 5 : 1;
    const inc = ex.inc;
    const res = (type, titre, raison, cKg, cReps) => ({ type, titre, raison, cible: { kg: cKg, reps: cReps }, date: d.date });

    if (minReps < item.min) {
      const prec = hist[hist.length - 2];
      const deuxFois = prec && Math.max(0, ...prec.series.map(s => s.kg || 0)) >= kg && Math.min(...prec.series.map(s => s.reps)) < item.min;
      if ((deuxFois || ressenti === 'echec') && kg > 0) {
        let bas = FM.arrondir(kg * 0.9, inc);
        if (bas >= kg) bas = Math.max(0, kg - inc);
        return res('baisse', `Allège à ${FM.fmt(bas)} kg`, 'Tu étais sous la fourchette de répétitions : baisse un peu pour retrouver une exécution propre.', bas, item.min);
      }
      return res('maintien', 'Même objectif', `Vise au moins ${item.min} ${u} sur chaque série avant d’augmenter.`, kg, item.min);
    }
    if (ressenti === 'echec') return res('maintien', 'Consolide', 'Séance à l’échec : refais la même chose avec plus de marge.', kg, Math.min(item.max, Math.max(item.min, minReps)));
    if (!complet) return res('maintien', 'Termine toutes les séries', `Fais les ${prevues} séries prévues avant d’augmenter.`, kg, Math.min(item.max, Math.max(item.min, minReps)));
    if (minReps >= item.max) {
      if (ressenti === 'difficile') return res('maintien', 'Confirme encore une fois', 'Haut de fourchette atteint mais difficile : répète avant d’augmenter.', kg, item.max);
      const double = ressenti === 'facile' && minReps >= item.max + 2;
      if (kg > 0 || (ex.mode === 'charge')) {
        const plus = FM.arrondir(kg + inc * (double ? 2 : 1), inc);
        return res('charge', `Monte à ${FM.fmt(plus)} kg`, `Toutes les séries à ${item.max} ${u} ou plus : augmente la charge et repars à ${item.min} ${u === 's' ? 's' : 'répétitions'}.`, plus, item.min);
      }
      return res('variante', 'Passe un cap', ex.lest ? `Haut de fourchette atteint : ajoute ${FM.fmt(inc)} kg de lest, ou ralentis la descente, ou choisis une variante plus dure.` : 'Haut de fourchette atteint : ralentis la descente, ajoute une pause ou choisis une variante plus dure.',
        ex.lest ? inc : 0, ex.lest ? item.min : minReps + pas);
    }
    if (ressenti === 'difficile') return res('maintien', 'Même objectif', 'C’était difficile : stabilise avant d’ajouter.', kg, minReps);
    const ajout = ressenti === 'facile' ? pas * 2 : pas;
    const cible = Math.min(item.max, minReps + ajout);
    return res('reps', `Vise ${cible} ${u} par série`, 'Ajoute des répétitions jusqu’au haut de la fourchette, puis augmente la charge.', kg, cible);
  };

  FM.fmt = n => (Number.isFinite(n) ? String(Math.round(n * 100) / 100).replace('.', ',') : '0');
})(typeof window !== 'undefined' ? window : globalThis);
