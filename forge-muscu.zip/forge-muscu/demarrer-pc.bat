@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Forge Muscu : http://localhost:8000
echo Laisse cette fenetre ouverte. Ferme-la pour arreter.
where py >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:8000
  py -m http.server 8000 --bind 127.0.0.1
) else (
  start "" http://localhost:8000
  python -m http.server 8000 --bind 127.0.0.1
)
pause
