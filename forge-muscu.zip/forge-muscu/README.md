# Forge Muscu

Application web installable (PWA) de musculation et de sport, en français, pour Android et PC.
Gratuite, sans compte, sans clé API. Les données restent sur ton appareil.

## Option A : Android + PC avec une adresse web gratuite (recommandé)

L'installation sur le téléphone demande une adresse **https**. GitHub Pages en fournit une gratuitement.

1. Sur le PC, décompresse `forge-muscu.zip` (clic droit → Extraire tout).
2. Crée un compte gratuit sur github.com, puis **New repository** : nom `forge-muscu`, visibilité **Public**, puis **Create repository**.
3. Sur la page du dépôt vide, clique **uploading an existing file**.
4. Ouvre le dossier `forge-muscu`, sélectionne **tout son contenu** (Ctrl+A) et glisse-le dans la page.
   `index.html` doit apparaître à la racine, avec les dossiers `css`, `js` et `icons`.
5. Clique **Commit changes**.
6. **Settings → Pages** : Source « Deploy from a branch », branche `main`, dossier `/ (root)`, **Save**.
7. Attends quelques minutes. L'adresse s'affiche : `https://TON-PSEUDO.github.io/forge-muscu/`.

### Installer sur Android
1. Ouvre l'adresse dans **Chrome**.
2. Menu **⋮** → **Installer l'application** (ou **Ajouter à l'écran d'accueil** → Installer).
3. Ouvre l'appli une fois avec internet. Dans **Profil**, vérifie « Prête à fonctionner hors ligne ».
4. Teste en mode avion.

### Installer sur PC
Dans Chrome ou Edge, ouvre l'adresse puis clique l'icône d'installation dans la barre d'adresse
(ou **Profil → Installer l'application**).

Le dépôt public contient seulement le code. Tes séances ne sont jamais envoyées sur GitHub.

## Option B : sur le PC uniquement, sans compte

1. Installe Python (python.org) si besoin.
2. Double-clique `demarrer-pc.bat`.
3. Le navigateur ouvre `http://localhost:8000` (actualise si la page s'affiche trop tôt). Garde la fenêtre noire ouverte.

Après le premier chargement, l'appli peut être installée depuis cette adresse.
Ouvrir directement `index.html` fonctionne pour essayer, mais sans installation ni mode hors ligne.

## Minuteur écran éteint

- Laisse **Profil → Sonner même écran éteint** activé et monte le volume **média**.
- Avant ta première séance : **Tester : repos de 10 secondes**, puis verrouille le téléphone.
- Si le son est coupé (Samsung) : Paramètres → Applications → Chrome → Batterie → **Non restreinte**.
- Ce mode peut mettre ta musique en pause. Si tu le décoches, la musique continue mais le bip
  n'est fiable qu'avec l'écran allumé.
- Ne ferme pas l'application pendant le repos. Après une fermeture, rouvre-la et touche **Activer le son**.

## Sauvegarde et transfert

- **Profil → Exporter en JSON** crée un fichier de sauvegarde.
- **Importer** sur un autre appareil *remplace* ses données (il n'y a pas de fusion ni de synchronisation).
- Chaque adresse (github.io, localhost, fichier local) a ses propres données.
- Effacer les données du site dans le navigateur efface ton historique : exporte régulièrement.

## Modifier l'application

Après un changement de fichier, augmente `VERSION` dans `sw.js` (`forge-muscu-v2`, etc.).
L'appli propose alors le bouton **Mettre à jour**.

## Fichiers

| Fichier | Rôle |
|---|---|
| `index.html`, `css/styles.css` | Page et design |
| `js/data.js` | Muscles, matériel, exercices |
| `js/program.js` | Génération du programme |
| `js/progression.js` | Records et propositions de progression |
| `js/store.js` | Sauvegarde, export, import |
| `js/timer.js` | Minuteur de repos, son, écran allumé |
| `js/ui.js`, `js/charts.js` | Composants et graphiques |
| `js/view-*.js`, `js/app.js` | Écrans et navigation |
| `sw.js`, `manifest.webmanifest`, `icons/` | Installation et hors ligne |
| `demarrer-pc.bat` | Serveur local Windows |
